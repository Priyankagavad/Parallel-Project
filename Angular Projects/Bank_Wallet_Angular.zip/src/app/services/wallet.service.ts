import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Account } from '../models/Account.model';
import { SampleResponse } from '../models/SampleResponse.model';
@Injectable({
  providedIn: 'root'
})
export class WalletService {
  fetched: boolean = false;
  static apiUrl = "http://localhost:5678/api";
  constructor(private http: HttpClient) {
  }
  create(name: string, mobile: string, dob: string, password: string): Promise<SampleResponse> {
    const url: string = `${WalletService.apiUrl}/create`;
    let account: Account = new Account(name, mobile, dob, password);
    return this.sendRequest(url, account);
  }
  private sendRequest(url: string, data: {}): Promise<any> {
    return this.http.post(url, data)
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }
  private handleError(error: any): Promise<any> {
    return Promise.reject(error.error || error);
  }
  deposit(amount: number, accountNum: string, password: string): Promise<SampleResponse> {
    const url: string = `${WalletService.apiUrl}/deposit`;
    let data = { account_number: accountNum, password: password, amount: amount };
    return this.sendRequest(url, data);
  }
  withdraw(amount: number, accountNum: string, password: string): Promise<SampleResponse> {
    const url: string = `${WalletService.apiUrl}/withdraw`;
    let data = { account_number: accountNum, password: password, amount: amount };
    return this.sendRequest(url, data);
  }
  transfer(amount: number, sender: string, password: string, receiver: string): Promise<SampleResponse> {
    const url: string = `${WalletService.apiUrl}/fund-transfer`;
    let data = { account_number: sender, password: password, amount: amount, receiver: receiver };
    return this.sendRequest(url, data);
  }
  balance(accountNum: string, password: string): Promise<SampleResponse> {
    const url: string = `${WalletService.apiUrl}/balance`;
    let data = { account_number: accountNum, password: password };
    return this.sendRequest(url, data);
  }
  transactions(accountNum: string, password: string): Promise<SampleResponse> {
    const url: string = `${WalletService.apiUrl}/transactions`;
    let data = { account_number: accountNum, password: password };
    return this.sendRequest(url, data);
  }
}

