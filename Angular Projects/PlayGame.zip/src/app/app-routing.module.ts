import { NgModule } from '@angular/core';

import { PlayComponent } from './Game2/PlayGames/play.component';
import { SuccessComponent } from './Game2/Success/success.component';
import { DummyComponent } from './Game1/dummy.component';
import { RouterModule, Routes } from '@angular/router';


const routes: Routes = [
  {path:"play", component:PlayComponent},
  {path:"success/:id", component:SuccessComponent},
  {path:'', component:DummyComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
