import { Injectable } from '@angular/core';
import { Game } from './games';
import { HttpClient } from '@angular/common/http';
import { Observable } from '../../../node_modules/rxjs';

@Injectable({
  providedIn: 'root'
})
export class GameService {

  game: Game[];

  cardBalance: number = 600;

  constructor(private http: HttpClient) {
      this.populateGame().subscribe( data => this.game = data, error => console.log(error) );    
   }

  populateGame(): Observable<Game[]> {
    return this.http.get<Game[]>("../../assets/GameList.json");
  }

  getGame(): Game[] {
    return this.game;
  }

  getCardBalance(rate: number): number {
      this.cardBalance = this.cardBalance-rate;
      return this.cardBalance;
  }
}
