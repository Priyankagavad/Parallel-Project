import { Component, OnInit } from '@angular/core';

import { GameService } from '../game.service';
import { Router } from '@angular/router';
import { Game } from '../games';

@Component({
  selector: 'app-play',
  templateUrl: './play.component.html',
  styleUrls: ['./play.component.css']
})
export class PlayComponent implements OnInit {

  game: Game[];
  cardBalance: number = 600;
  constructor(private gameService: GameService, private router: Router) { }

  ngOnInit() {
    this.game = this.gameService.getGame();
  }

}
