import { Component, OnInit } from '@angular/core';
import { GameService } from '../game.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Game } from '../games';

@Component({
  selector: 'app-success',
  templateUrl: './success.component.html',
  styleUrls: ['./success.component.css']
})
export class SuccessComponent implements OnInit {

  game: Game;

  currBalance: number;

  constructor(private gameService: GameService, private activatedRoute: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    let gameId: string = this.activatedRoute.snapshot.params["id"];
    this.game = this.gameService.getGame().find(game=> game.gameId == gameId);

    this.currBalance = this.gameService.getCardBalance(this.game.gamePrice);
  }


  navigate(path: string) {
    this.router.navigate(["/play"]);    
  }

}
