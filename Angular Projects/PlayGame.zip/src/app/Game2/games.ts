export interface Game {
    gameId: string;
    gameName: string;
    gamePrice: number;
}