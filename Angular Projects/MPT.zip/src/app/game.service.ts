import { Injectable } from '@angular/core';
import { Game } from './gameInterface';
import { HttpClient } from '@angular/common/http';
import { Observable } from '../../node_modules/rxjs';


@Injectable({
  providedIn: 'root'
})
export class GameService {

  game:Game[];
  constructor(private http:HttpClient) {
    this.populateGames().subscribe(data=>this.game=data, error=>console.log(error));
   }
  populateGames():Observable<Game[]>{
    return this.http.get<Game[]>("../../assets/GameList.json");
  }
  getGames():Game[]{
    return this.game;
  }
  
  
}
