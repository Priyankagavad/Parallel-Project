import { Component, OnInit, Input, EventEmitter, Output  } from '@angular/core';


@Component({
  selector: 'app-employee-count',
  templateUrl: './employee-count.component.html',
  styleUrls: ['./employee-count.component.css']
})
export class EmployeeCountComponent implements OnInit {

  selectedRadioButtonValue:string="all";

  @Output()
  countRadioButtonValueChange:EventEmitter<string>=new EventEmitter<string>();

  @Input()
  all:number;

  @Input()
  male:number;

  @Input()
  female:number;
  constructor() { }

  ngOnInit() {
  }

  countRadioButtonValueChanged(data:string){
    this.countRadioButtonValueChange.emit(this.selectedRadioButtonValue);
  }
}
