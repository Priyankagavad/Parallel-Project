import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder} from '@angular/forms';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  userForm:FormGroup;
  constructor(private formBuilder:FormBuilder){}
  /*userForm:FormGroup=new FormGroup({
    name: new FormControl("Anthony",[Validators.required, Validators.minLength(4), Validators.maxLength(10)]),
    email: new FormControl(),
    address:new FormGroup({
      street: new FormControl(),
      city: new FormControl(),
      pincode: new FormControl(null, Validators.pattern("[1-9][0-9]{5}"))
    })
  });
  process(){
    console.log(this.userForm.value);
  }
  process() {
    alert("Welcome");
  }
  processData(event) {
    this.name = event.target.value;
  }
  name: string = "Tom";
  day: number = 2;
  content: string = "Hello world";

  processForm(value: any) {
    console.log(value);
  }*/

  ngOnInit(){
    this.userForm=this.formBuilder.group({
      name:[null, [Validators.minLength(4),Validators.maxLength(10)]],
      email:[],
      address:this.formBuilder.group({
        street:[],
        city:[],
        pincode:[null, Validators.pattern("[1-9][0-9]{5}")]
      })
    });
  }
  process(){
    console.log(this.userForm.value);
  }
}
