import { Directive, Renderer, HostListener, ElementRef, HostBinding } from '@angular/core';

@Directive({
  selector: '[appDemo]'
})
export class DemoDirective {

  @HostBinding('style.border')
  border:string;
  @HostListener('click')
  onclick(){
    this.renderer.setElementStyle(this.el.nativeElement, 'color', 'green');
    //this.renderer.setElementStyle(this.el.nativeElement, 'border', '3px solid red');
    this.border='3px solid red';
  }
  constructor(private el:ElementRef, private renderer:Renderer) { }

}
