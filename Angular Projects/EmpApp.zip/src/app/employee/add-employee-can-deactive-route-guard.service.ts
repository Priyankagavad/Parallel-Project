import { Injectable } from '@angular/core';
import { CanDeactivate } from '../../../node_modules/@angular/router';
import { AddEmployeeComponent } from './add-employee.component';

@Injectable({
  providedIn: 'root'
})
export class AddEmployeeCanDeactiveRouteGuardService implements CanDeactivate<AddEmployeeComponent> {

  canDeactivate(component: AddEmployeeComponent): boolean {
    if (component.createEmployeeForm.dirty) {
      return confirm("Are you sure you want to discard the Data(y/n)?");
    }
    return true;
  }
  constructor() { }
}
