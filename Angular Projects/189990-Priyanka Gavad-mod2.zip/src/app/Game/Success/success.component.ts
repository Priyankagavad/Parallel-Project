import { Component, OnInit } from '@angular/core';
import { GameService } from '../game.service';
import { ActivatedRoute, Router } from '../../../../node_modules/@angular/router';
import { Games } from '../games';

@Component({
  selector: 'app-success',
  templateUrl: './success.component.html',
  styleUrls: ['./success.component.css']
})
export class SuccessComponent implements OnInit {

  game: Games;

  currBalance: number;

  constructor(private gameService: GameService, private activatedRoute: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    let gameId: number = this.activatedRoute.snapshot.params["id"];
    this.game = this.gameService.getGames().find(game=> game.gameId == gameId);

    this.currBalance = this.gameService.getCardBalance(this.game.gamePrice);
  }


  navigate(path: string) {
    this.router.navigate(["/play"]);    
  }

}
