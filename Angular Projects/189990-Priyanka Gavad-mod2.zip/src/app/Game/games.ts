export interface Games {
    gameId: number;
    gameName: string;
    gamePrice: number;
}