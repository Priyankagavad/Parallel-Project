import { Component, OnInit } from '@angular/core';
import { GameService } from '../Game/game.service';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-dummy',
  templateUrl: './dummy.component.html',
  styleUrls: ['./dummy.component.css']
})
export class DummyComponent implements OnInit {

  constructor(private gameService: GameService, private router: Router) { }

  ngOnInit() {
    setTimeout( ()=> {
      this.router.navigate(['/play']);
    },20 )
  }

}
