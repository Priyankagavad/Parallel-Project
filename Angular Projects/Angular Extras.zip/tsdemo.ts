function greeter(person){
    return "Hello" + person;
}
var user = "Smith";
document.body.textContent = greeter(user);