var message = "Greetings of the day!";
console.log(message);
