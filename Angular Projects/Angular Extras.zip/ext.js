var a=10;

function myfun(){
    console.log('Welcome to console');
}