import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddAlbumComponent } from './MusicStore/add-album.component';
import { AlbumListComponent } from './MusicStore/album-list.component';
import { AlbumService } from './MusicStore/album.service';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { SearchAlbumComponent } from './MusicStore/search-album.component';

@NgModule({
  declarations: [
    AppComponent,
    AddAlbumComponent,
    AlbumListComponent,
    SearchAlbumComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

