import { Injectable } from '@angular/core';
import { Music } from './music';
import { HttpClient } from '@angular/common/http';
import { Observable } from '../../../node_modules/rxjs';


@Injectable({
  providedIn: 'root'
})
export class AlbumService {


 music:Music[];
  constructor(private http:HttpClient) {
    this.populateAlbum().subscribe(data=>this.music=data, error=>console.log(error));
   }
  populateAlbum():Observable<Music[]>{
    return this.http.get<Music[]>("../../assets/music.json");
  }
  getAlbum():Music[]{
    return this.music;
  }
  addAlbum(music:Music){
    return this.music.push(music);
    return this.getAlbum();
  }
  deleteAlbum(id){
    if(window.confirm("Do You Want to Delete!!!!")){
      this.music=this.music.filter(emp=>emp.id!=id);
    }
 
  }
}


