import { Component, OnInit } from '@angular/core';
import { Music } from './music';
import { AlbumService } from './album.service';

@Component({
  selector: 'app-search-album',
  templateUrl: './search-album.component.html',
  styleUrls: ['./search-album.component.css']
})
export class SearchAlbumComponent implements OnInit {

  music:Music[];
  constructor(private albumService:AlbumService) { }

  ngOnInit() {
  }

  search(data){
    console.log(data.searchTerm);
    this.music=this.albumService.getAlbum().filter(emp=>emp.artist===data.searchTerm);

    if(this.music.length==0){
      this.music=this.albumService.getAlbum().filter(emp=>emp.title.toLowerCase()===data.searchTerm.toLowerCase());
    }
  }

}

