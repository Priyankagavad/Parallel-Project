import { Component, OnInit } from '@angular/core';
import { Music } from './music';
import { AlbumService } from './album.service';

@Component({
  selector: 'app-album-list',
  templateUrl: './album-list.component.html',
  styleUrls: ['./album-list.component.css']
})
export class AlbumListComponent implements OnInit {

  music:Music[];

  constructor(private albumService:AlbumService) { }

  ngOnInit() {
    this.music=this.albumService.getAlbum();
  }
  deleteAlbum(id){
    this.albumService.deleteAlbum(id);
    this.music=this.albumService.getAlbum();
  }

}


