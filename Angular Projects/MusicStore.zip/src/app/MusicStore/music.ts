export interface Music{
     id:number;
     title:string;
     artist:string;
     price:number;                                                                            
}