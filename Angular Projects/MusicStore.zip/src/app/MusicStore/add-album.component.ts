import { Component, OnInit } from '@angular/core';
import { AlbumService} from './album.service';
import {Router} from '@angular/router';
import { Music } from './music';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-add-album',
  templateUrl: './add-album.component.html',
  styleUrls: ['./add-album.component.css']
})
export class AddAlbumComponent implements OnInit {

  constructor(private albumService:AlbumService, private router:Router) { }

  ngOnInit() {
  }

  onSubmit(music:Music){
    this.albumService.addAlbum(music);
    this.router.navigate(["/list"]);
  }

}

