import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddAlbumComponent } from './MusicStore/add-album.component';
import { AlbumListComponent } from './MusicStore/album-list.component';
import { SearchAlbumComponent } from './MusicStore/search-album.component';


const routes: Routes = [
  {path:"add",component:AddAlbumComponent},
  {path:"list",component:AlbumListComponent},
  {path:"search",component:SearchAlbumComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
