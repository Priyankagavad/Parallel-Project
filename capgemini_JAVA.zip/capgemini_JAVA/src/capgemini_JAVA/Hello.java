package capgemini_JAVA;
// Priyanka Gavad
// Date: 24-July-2019
// Purpose: To print Helloo.....

public class Hello{
	public static void main(String args[]){
	System.out.println("Hello");
	}
}