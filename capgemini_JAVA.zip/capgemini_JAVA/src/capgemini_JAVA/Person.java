package capgemini_JAVA;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;

public class Person {

	
	public static void main(String[] args) {
		List<String> list = new ArrayList<>();
		list.add("Hello");
		list.add("World");
		Consumer<List<String>> consumer=Collections::reverse;
		consumer.accept(list);
		System.out.println(list);
	}
	
}

