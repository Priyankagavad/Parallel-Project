package capgemini_JAVA;
// Priyanka Gavad
// Date: 24-July-2019
// Purpose: Data Type Range

public class DataTypeRange{
	public static void main(String args[]){
	System.out.println("Byte: Min & Max Value:"+Byte.MIN_VALUE+":"+Byte.MAX_VALUE);
	System.out.println("Short: Min & Max Value:"+Short.MIN_VALUE+":"+Short.MAX_VALUE);
	System.out.println("Integer: Min & Max Value:"+Integer.MIN_VALUE+":"+Integer.MAX_VALUE);
	System.out.println("Long: Min & Max Value:"+Long.MIN_VALUE+":"+Long.MAX_VALUE);
	System.out.println("Float: Min & Max Value:"+Float.MIN_VALUE+":"+Float.MAX_VALUE);
	System.out.println("Double: Min & Max Value:"+Double.MIN_VALUE+":"+Double.MAX_VALUE);
	System.out.println("Boolean: True false value:"+Boolean.TRUE+":"+Boolean.FALSE);
	System.out.println("Character: Min & Max Value:"+Character.MIN_VALUE+":"+Character.MAX_VALUE);
	}
}