package capgemini_JAVA;
// Priyanka Gavad
// Date: 24-July-2019
// Purpose: Data Types

public class DataType{
	public static void main(String args[]){
	
	// declare data types....
	int empID;
	String name;
	char gender;
	boolean isWorking;
	float salary;

	// Initialisation
	empID=201;
	name=null;
	gender='M';
	isWorking=true;
	salary=36223.67f;

	System.out.println("EmpID:"+empID);
	System.out.println("Name:"+name);
	System.out.println("Gender:"+gender);
	System.out.println("Working:"+isWorking);
	System.out.println("salary:"+salary);
	}
}