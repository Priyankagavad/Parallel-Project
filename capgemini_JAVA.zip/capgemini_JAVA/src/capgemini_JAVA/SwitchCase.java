package capgemini_JAVA;
// Priyanka Gavad
// Date: 24-July-2019
// Purpose: Use switch case
//          to find out season from a given month

public class SwitchCase{
	public static void main(String args[]){
	int month=4; // April
	String season=null;
	
	switch(month){
		case 12 :
		case 1 :
		case 2 :		
			season = "winter";
			break;
		
		case 3:
		case 4:	
		case 5:		
			season = "spring";
			break;

		case 6:
		case 7:
		case 8:	
			season = "summer";
			break;

		case 9:
		case 10:	
		case 11:
			season = "Automn";
			break;

		default:
			season="Bogus month";		
	}
	
	System.out.println("Season: " + season);
	}
}