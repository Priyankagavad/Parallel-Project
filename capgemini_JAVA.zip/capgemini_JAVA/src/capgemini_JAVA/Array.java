package capgemini_JAVA;

import java.util.Arrays;

public class Array {
	static int Minimum(){
		
	};
	public static void main(String[] args) {
		/*
		// declaration
		int[] nums;
		// initialization
		nums = new int[5];
		*/
		int[] nums = {1, 2, 3, 4, 5};
		Minimum m=Minimum(nums);
		
		
		for(int index=0; index < nums.length; index++){
		System.out.println(nums[index]);    // 0
		}
		
		// enhanced for loop - jdk 1.5
		for (int num:nums){
			System.out.println(num);
			}
		
		char[] vowels = {'A', 'E', 'I', 'O', 'U'};
		System.out.println(Arrays.toString(vowels));
		
		String[] countrys = { "China", "India", "Japan"};
		System.out.println(Arrays.toString(countrys));
		for(String country:countrys){
			System.out.println(country);
		}
	}
}
