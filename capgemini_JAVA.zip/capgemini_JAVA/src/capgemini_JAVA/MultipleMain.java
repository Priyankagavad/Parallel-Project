package capgemini_JAVA;
// Priyanka gavad
// Date:24-July-2019
// Purpose: To print multiple main...

public class MultipleMain{
	public static void main(String args[]){
	System.out.println("Hello...");
	// calling another main method....
	main(new int[] {});
	}

	//main can be overloaded
	public static void main(int[] args){
	System.out.println("Hii....");
	}
}