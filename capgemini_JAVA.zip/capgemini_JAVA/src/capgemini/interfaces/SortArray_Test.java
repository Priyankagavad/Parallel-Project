package capgemini.interfaces;

import java.util.Arrays;

interface ArraySort {
	public abstract void SortAsc(int[] nos);

	void print();

	public abstract void SortDesc(int[] nos);
}

class ArraySortImpl implements ArraySort {
	int[] nums;

	public ArraySortImpl(int[] nos) {
		this.nums = nos;
	}

	int small = nums[0];

	@Override
	public void SortAsc(int[] nos) {
		for (int i = 0; i <= nos.length; i++) {
			if (nos[i] < small) {
				small = nos[i];
				nums[i] = small;
			}
		}
	}

	int large = nums[0];

	@Override
	public void SortDesc(int[] nos) {
		for (int i = 0; i <= nos.length; i++) {
			if (nos[i] > large) {
				large = nos[i];
				nums[i] = large;
			}

		}

	}
	
	@Override 
	public void print() {
		System.out.println(Arrays.toString(nums));
	}
}

public class SortArray_Test {
	int[] nums = {1, 2, 5, 3, 7, 10, 4, 6, 8, 9};
	 ArraySortImpl  arraySortImpl = new  ArraySortImpl(nums);
	 arraySortImpl.sortAsc();
	 arraySortImpl.print();
	}

