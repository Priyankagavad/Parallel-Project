package capgemini.interfaces;

interface Calculator {
	// by default methods are public & abstract
	int add(int no1, int no2);

	public abstract int sub(int no1, int no2);
}

interface AdvCalculator {
	int mul(int no1, int n02);

	int div(int no1, int no2);
}

// interfaces are implemented via class
class CalculatorImpl implements Calculator, AdvCalculator {
	// The type CalculatorImpl must implement the inherited abstract method
	// Calculator.add(int, int)
	@Override
	public int add(int no1, int no2) {
		return no1 + no2;
	}

	@Override
	public int sub(int no1, int no2) {
		return no1 - no2;
	}

	@Override
	public int mul(int no1, int no2) {
		return no1 * no2;
	}

	@Override
	public int div(int no1, int no2) {
		return no1 / no2;
	}
}

public class Calculator_Test {
	public static void main(String[] args) {
		Calculator calc;
		AdvCalculator advcalc;
		// cannot instantiate the type calculator
		// calc=new Calculator(); we cannot create instance of interface

		CalculatorImpl calculatorImpl = new CalculatorImpl();
		System.out.println("Add:" + calculatorImpl.add(10, 20));
		System.out.println("sub:" + calculatorImpl.sub(20, 5));
		System.out.println("Mul:" + calculatorImpl.mul(10, 20));
		System.out.println("Div:" + calculatorImpl.div(10, 2));
		
		// ref pointer
		// calc = calculatorImpl;
		calc = new CalculatorImpl();
		System.out.println("Add:" + calc.add(10, 20));
		System.out.println("sub:" + calc.sub(20, 5));
		// System.out.println("Mul:" + calc.mul(10, 20));
		// System.out.println("Div:" + calc.div(10, 2));
		
		// advcalc = calculatorImpl;
		advcalc = new CalculatorImpl();
		// System.out.println("Add:" + advcalc.add(10, 20));
		// System.out.println("sub:" + advcalc.sub(20, 5));
		System.out.println("Mul:" + advcalc.mul(10, 20));
		System.out.println("Div:" + advcalc.div(10, 2));
	}
}
