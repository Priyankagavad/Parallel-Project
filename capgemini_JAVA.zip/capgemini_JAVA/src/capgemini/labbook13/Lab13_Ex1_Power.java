package capgemini.labbook13;

import java.util.Scanner;

@FunctionalInterface
interface Raise {
	double Power(int x, int y);
}

public class Lab13_Ex1_Power {
	public static void main(String args[]) {
		Raise lab = (x, y) -> {
			return (Math.pow(x, y));
		};
		Scanner sc = new Scanner(System.in);
		int x = sc.nextInt();
		int y = sc.nextInt();

		System.out.println(lab.Power(x, y));
		sc.close();
	}
}
