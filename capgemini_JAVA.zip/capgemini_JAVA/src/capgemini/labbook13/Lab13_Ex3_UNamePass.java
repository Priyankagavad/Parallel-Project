package capgemini.labbook13;

import java.util.Scanner;

interface Validate {
	boolean insert(String uname, String pass);
}

public class Lab13_Ex3_UNamePass {

	public static void main(String[] args) {
		Validate v1 = (String uname, String pass) -> {
			if (uname != null && pass != null) {
				return true;
			} else {
				return false;
			}

		};

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the UName: ");
		String uname = sc.next();
		System.out.println("Enter the password: ");
		String pass = sc.next();
		boolean i = v1.insert(uname, pass);
		if (i == true) {
			System.out.println("Succesfull authentication");
		} else {
			System.out.println("UnSuccesfull");
		}
		sc.close();
	}

}
