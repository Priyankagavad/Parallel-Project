package capgemini.labbook13;

import java.util.Scanner;

interface Space {
	void insert(String str);
}

public class Lab13_Ex2_CG {

	public static void main(String[] args) {
		Space sp = (String str) -> {
			for (int i = 0; i < str.length(); i++) {
				System.out.println(str.charAt(i) + " ");
			}
		};

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String: ");
		String str = sc.next();
		sp.insert(str);
		sc.close();
	}

}
