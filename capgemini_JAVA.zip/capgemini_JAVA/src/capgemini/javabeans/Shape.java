package capgemini.javabeans;

public abstract class Shape {
	// default constructor
	public Shape() {
		System.out.println("Shape->def.......");
	}
	
	// methods........
	public void draw() {
		System.out.println("Shape is drawn.......");
	}
	public abstract double calcArea();
	
}
