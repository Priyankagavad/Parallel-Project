package capgemini.javabeans;

public class Rectangle {

	// field
	private float length, breadth;

	// default......
	public Rectangle() {
		// to call another constructor
		this(0.0f, 0.0f); // will call parameter construtor
		System.out.println("Rectangle->def....");
	}

	public Rectangle(float length, float breadth) {
		// this.length = length;
		// this.breadth =breadth;
		setLength(length);
		setBreadth(breadth);
		System.out.println("Rectangle->parameter.....");
	}

	// setter method
	public void setLength(float length) {
		if (length > 0)
			this.length = length;
	}

	// getter method
	public float getLength() {
		return length;
	}

	// setter method
	public void setBreadth(float breadth) {
		if (breadth > 0)
			this.breadth = breadth;
	}

	// getter method
	public float getBreadth() {
		return breadth;
	}

	public double calcArea() {
		return length * breadth;
	}

	@Override
	public String toString() {
		return "Rectangle [length=" + getLength() + ", breadth=" + getBreadth() + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Rectangle other = (Rectangle) obj;
		if (Float.floatToIntBits(breadth) != Float.floatToIntBits(other.breadth))
			return false;
		if (Float.floatToIntBits(length) != Float.floatToIntBits(other.length))
			return false;
		return true;
	}

	public static Rectangle whoisBiggerOne(Rectangle rectOne, Rectangle rectTwo) {
		if (rectOne.getLength() > rectTwo.getLength())
			return rectOne;
		else
			return rectTwo;
	}

	public static void main(String[] args) {
		Rectangle r1, r2;
		r1 = new Rectangle(3.5f, 5.5f);
		r2 = new Rectangle(4.5f, 6.5f);

		Rectangle bigger1 = Rectangle.whoisBiggerOne(r1, r2);
		Rectangle bigger2 = ShapeUtility.whoisBiggerTwo(r1, r2);

	}

}
