package capgemini.javabeans;

public class Employee {
	private int empID;
	private String name;
	public static int COUNT;
	public static int SEQUENCE;
	
	static{
		SEQUENCE=100;
		COUNT=0;
		System.out.println("I am in static block......");
	}
	
	public Employee(){
		super();
		empID = ++SEQUENCE;
		COUNT++;
		// System.out.println("I am in a default constructor...");
	}
	
	public Employee(String Name){
		super();
		// this.empID = empID;
		//this.name = name;
		setEmpID(empID);
		setName(name);
		empID = ++SEQUENCE;
		COUNT++;
		System.out.println("I am in a parameter constructor.....");
	}
	
	public int getempID(){
		return empID;
	}
	
	public void setEmpID(int empID){
		this.empID = empID;
	}
	
	public String getName(){
		return name;
	}
	
	public void setName(String name){
		this.name = name;
	}
	
	
	
	
	public String toString_StringBuilder_Chained() {
		StringBuilder builder = new StringBuilder();
		builder.append("Employee [empID=").append(empID).append(", name=").append(name);
		return builder.toString();
	}

	
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("Employee Details: EmpID:");
		buffer.append(empID);
		buffer.append("Name:");
		buffer.append(name);
		return buffer.toString();
	}
	
	public String toString_StringBuilder() {
		StringBuilder builder2 = new StringBuilder();
		builder2.append("Employee [empID=");
		builder2.append(empID);
		builder2.append(", name=");
		builder2.append(name);
		builder2.append("]");
		return builder2.toString();
	}
	
	// return "Employee [empID=" + empID + ", name=" + name + "]";
	
}
