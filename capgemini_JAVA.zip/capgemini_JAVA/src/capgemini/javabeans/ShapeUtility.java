package capgemini.javabeans;

public class ShapeUtility {
	// no instance field.....
	// no instance methods....
	// All static fields only...
	// All static methods only....
	public static Rectangle whoisBiggerTwo(Rectangle rectOne, Rectangle rectTwo) {
		if (rectOne.getLength() > rectTwo.getLength())
			return rectOne;
		else
			return rectTwo;
	}
}
