package capgemini.javabeans;

public class Triangle {
	// fields
	    private float base, height;
	
	// default constructor
	public Triangle(){
		base = 0.0f;
		height = 0.0f;
		System.out.println("Triangle definition........");
	}
	
	// parameter constructor
	public Triangle(float base, float height){
		this.base = base;
		this.height = height;
		System.out.println("Triangle parameter....");
	}
	
	// methods
	public void draw(){
		System.out.println("Triangle is drawn");
	}
	
	public double calcArea(){
		return (base*height)/2;
	}
	
	// setter method
	public void setBase(float base){
		if(base > 0)
			this.base = base;
	}
	
	public void setHeight(float height){
		if(height > 0)
			this.height = height;
	}
	
	// getter method
	public float getBase(){
		return base;
	}
	
	public float getHeight(){
		return height;
	}
	
	@Override
	public String toString() {
		return "Triangle [base=" + base + ", height=" + height + "]";
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Triangle other = (Triangle) obj;
		if (Float.floatToIntBits(base) != Float.floatToIntBits(other.base))
			return false;
		if (Float.floatToIntBits(height) != Float.floatToIntBits(other.height))
			return false;
		return true;
	}

	public static void main(String[] args) {
		Triangle t1;
		t1 = new Triangle(2.0f, 2.0f);
		System.out.println("Triangle Area:" + t1.calcArea());
		
	}

	
}


