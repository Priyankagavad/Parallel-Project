package capgemini.javabeans;

public class Circle_Test {
	public static void main(String[] args) {
		// declaration
		Rectangle r1;
		// object instantiation
		r1 = new Rectangle();
		// accessing field of an object
		r1.radius=5.5f;
		// accessing method of an object
		r1.showRadius();
	}


}
