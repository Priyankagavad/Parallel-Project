package capgemini.javabeans;

public class Shape_Test {
	public static void main(String[] args) {
	Rectangle r1;
	Circle c1;
	r1 = new Rectangle(2.0f, 2.0f);
	c1 = new Circle(3.0f);
	System.out.println("Circle Area" + c1.calcArea());
	System.out.println("Rectangle Area:" + r1.calcArea());
}
}
