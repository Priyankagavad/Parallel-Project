package capgemini.javabeans;

public class Rectangle_Test {
	public static void main(String[] args) {
		// declaration
		Rectangle r1;
		// object instantiation
		r1 = new Rectangle();
		// accessing field of an object
		r1.setLength(2.0f);
		r1.setBreadth(2.0f);
		// accessing method of an object
		System.out.println("Area:" + r1.calcArea());
	}
}
