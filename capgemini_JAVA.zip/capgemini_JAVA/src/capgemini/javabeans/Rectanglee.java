package capgemini.javabeans;

public class Rectanglee extends Shape {
	// fields
	double length, breadth;
	
	// default constructor
	public Rectanglee(){
		super();
		length=0.0f;
		breadth=0.0f;
		}
	
	// parameter constructor
	public Rectanglee(float length, float breadth){
		super();
		length = 2.0f;
		breadth = 2.0f;
	}

	@Override
	public double calcArea() {
		return length*breadth;
	}
		
	

}
