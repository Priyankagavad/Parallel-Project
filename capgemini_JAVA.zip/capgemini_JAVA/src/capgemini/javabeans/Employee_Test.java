package capgemini.javabeans;

public class Employee_Test {
	public static void main(String[] args) {
	Employee e1, e2, e3;
	e1 = new Employee("abc" );
	e2 = new Employee("pqr");
	e3 = new Employee("xyz");
	
	System.out.println("Employee Count:" + Employee.COUNT);
	System.out.println("Last Employee ID:" + Employee.SEQUENCE);
	}
}
