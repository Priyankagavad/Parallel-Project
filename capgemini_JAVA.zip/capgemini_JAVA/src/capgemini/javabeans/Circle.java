package capgemini.javabeans;

public class Circle extends Shape{
	// fields
	float radius;
	
	// default constructor
	public Circle(){
		super();
		radius=0.0f;
		System.out.println("Circle->def");
	}
	
	public Circle(float radius){
		super();
		this.radius=radius;
		System.out.println("circle->parameter");
	}
	
	@Override
	public void draw(){
		super.draw();
		System.out.println("circle is drawn");
	}
	
	@Override
	public double calcArea(){
		return radius*radius*Math.PI;
	}
}
