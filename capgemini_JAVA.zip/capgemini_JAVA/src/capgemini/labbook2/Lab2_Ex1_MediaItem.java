package capgemini.labbook2;

abstract public class Lab2_Ex1_MediaItem extends Lab2_Ex1_Item {
	private int var;

	public int getVar() {
		return var;
	}

	public void setVar(int var) {
		this.var = var;
	}

	@Override
	public String toString() {
		return "MediaItem [var=" + var + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Lab2_Ex1_MediaItem other = (Lab2_Ex1_MediaItem) obj;
		if (var != other.var)
			return false;
		return true;
	}

}
