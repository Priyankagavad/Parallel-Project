package capgemini.labbook2;

public class Lab2_Ex1_Video extends Lab2_Ex1_MediaItem {
	private String director;
	private String genre;
	private int releaseYear;

	public Lab2_Ex1_Video() {
	}

	public Lab2_Ex1_Video(String director, String genre, int releaseYear) {
		super();
		setDirector(director);
		setGenre(genre);
		setReleaseYear(releaseYear);
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public int getReleaseYear() {
		return releaseYear;
	}

	public void setReleaseYear(int releaseYear) {
		this.releaseYear = releaseYear;
	}

	@Override
	public void checkIn() {
		System.out.println("Checked In->Video");
	}

	@Override
	public void checkOut() {
		System.out.println("Checked Out->Video");
	}

	@Override
	public void addItem() {
		System.out.println("Video added");
	}

	@Override
	public void print() {
		System.out.println("Director: " + director + "Genre: " + genre + "Year Released: " + releaseYear);
	}

}
