package capgemini.labbook2;

abstract public class Lab2_Ex1_Item {
	private int IdentificationNumber;
	private String title;
	private int noOfCopies;

	public abstract void checkIn();

	public abstract void checkOut();

	public abstract void print();

	public abstract void addItem();

	public Lab2_Ex1_Item() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Lab2_Ex1_Item(int identificationNumber, String title, int noOfCopies) {
		super();
		IdentificationNumber = identificationNumber;
		this.title = title;
		this.noOfCopies = noOfCopies;
	}

	public int getUniIdenNumber() {
		return IdentificationNumber;
	}

	public void setUniIdenNumber(int uniIdenNumber) {
		this.IdentificationNumber = uniIdenNumber;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getNoOfCopies() {
		return noOfCopies;
	}

	public void setNoOfCopies(int noOfCopies) {
		this.noOfCopies = noOfCopies;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Lab2_Ex1_Item other = (Lab2_Ex1_Item) obj;
		if (noOfCopies != other.noOfCopies)
			return false;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		if (IdentificationNumber != other.IdentificationNumber)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Item [uniIdenNumber=" + IdentificationNumber + ", title=" + title + ", noOfCopies=" + noOfCopies + "]";
	}

}
