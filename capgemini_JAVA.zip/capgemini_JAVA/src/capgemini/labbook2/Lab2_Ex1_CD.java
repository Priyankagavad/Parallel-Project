package capgemini.labbook2;

public class Lab2_Ex1_CD extends Lab2_Ex1_MediaItem {
	private String artist;
	private String genre;

	public Lab2_Ex1_CD() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Lab2_Ex1_CD(String artist, String genre) {
		super();
		this.artist = artist;
		this.genre = genre;
	}

	@Override
	public void checkIn() {
		System.out.println("Checked In->Cd");
	}

	@Override
	public void checkOut() {
		System.out.println("Checked Out->CD");
	}

	@Override
	public void addItem() {
		System.out.println("CD added");
	}

	@Override
	public void print() {
		System.out.println("Artist: " + artist + "Genre: " + genre);
	}

}
