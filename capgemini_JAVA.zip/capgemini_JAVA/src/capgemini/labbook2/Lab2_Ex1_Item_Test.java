package capgemini.labbook2;

public class Lab2_Ex1_Item_Test {

	public static void main(String[] args) {
		Lab2_Ex1_WrittenItem wItem1 = new Lab2_Ex1_Book();
		wItem1.setAuthor("akjk");
		System.out.println(wItem1.toString());
		Lab2_Ex1_WrittenItem wItem2 = new Lab2_Ex1_JournalPaper(1992);
		wItem2.print();
		Lab2_Ex1_MediaItem mItem1 = new Lab2_Ex1_CD("xyz", "classic");
		mItem1.print();
		Lab2_Ex1_MediaItem mItem2 = new Lab2_Ex1_Video("xyz", "classic", 2010);
		mItem2.print();
	}

}
