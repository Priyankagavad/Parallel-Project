package capgemini.labbook2;

public class Lab2_Ex1_Book extends Lab2_Ex1_WrittenItem {
	@Override
	public void checkIn() {
		System.out.println("Checked In->Book");
	}

	@Override
	public void checkOut() {
		System.out.println("Checked Out->Book");
	}

	@Override
	public void addItem() {
		System.out.println("Book added");
	}

	@Override
	public void print() {
		super.toString();
	}

}
