package capgemini.labbook2;

public class Lab2_Ex1_JournalPaper extends Lab2_Ex1_WrittenItem {
	private int yearPublished;

	public Lab2_Ex1_JournalPaper() {
	}

	public Lab2_Ex1_JournalPaper(int yearPublished) {
		super();
		setYearPublished(yearPublished);
	}

	public int getYearPublished() {
		return yearPublished;
	}

	public void setYearPublished(int yearPublished) {
		this.yearPublished = yearPublished;
	}

	@Override
	public void checkIn() {
		System.out.println("Checked In->Journal Paper");
	}

	@Override
	public void checkOut() {
		System.out.println("Checked Out->Journal Paper");
	}

	@Override
	public void addItem() {
		System.out.println("Journal Paper added");
	}

	@Override
	public void print() {
		System.out.println("Year published: " + yearPublished);

	}
}
