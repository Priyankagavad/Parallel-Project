package capgemini.labbook2;

abstract public class Lab2_Ex1_WrittenItem extends Lab2_Ex1_Item {

	private String author;

	public Lab2_Ex1_WrittenItem() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Lab2_Ex1_WrittenItem(int identificationNumber, String title, int noOfCopies) {
		super(identificationNumber, title, noOfCopies);
		// TODO Auto-generated constructor stub
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	@Override
	public String toString() {
		return "WrittenItem [author=" + author + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Lab2_Ex1_WrittenItem other = (Lab2_Ex1_WrittenItem) obj;
		if (author == null) {
			if (other.author != null)
				return false;
		} else if (!author.equals(other.author))
			return false;
		return true;
	}

}
