package capgemini.labbook3;

import java.util.Arrays;
import java.util.Scanner;

public class Lab3_Ex1_SecondSmallestNo {
	public static int getSecondSmallest(int[] arr) {
		Arrays.sort(arr);
		System.out.println("Sorted Order:" + Arrays.toString(arr));
		return arr[1];
	}

	public static void main(String[] args) {
		int num, result = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no. of elements:");
		num = sc.nextInt();
		System.out.println("Enter numbers you want to sort:");
		int arr[] = new int[num];
		for (int i = 0; i < num; i++) {
			arr[i] = sc.nextInt();
		}
		result = getSecondSmallest(arr);
		System.out.println("Second smallest number is:\t" + result);
		sc.close();
	}

}
