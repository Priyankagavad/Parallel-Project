package capgemini.labbook3;

import java.util.Arrays;
import java.util.Scanner;

public class Lab3_Ex2_StringSort {
	public static String getSortedString(String[] arr) {
		int n = arr.length;
		String arr1[] = new String[n];
		Arrays.sort(arr);
		if (n % 2 == 0) {
			for (int index = 0; index < n / 2; index++) {
				arr1[index] = arr[index].toUpperCase();
			}
			for (int index = n / 2; index < n; index++) {
				arr1[index] = arr[index].toLowerCase();
			}
		} else {
			for (int index = 0; index < (n / 2) + 1; index++) {
				arr1[index] = arr[index].toUpperCase();
			}
			for (int index = (n / 2) + 1; index < n; index++) {
				arr1[index] = arr[index].toLowerCase();
			}

		}

		return Arrays.toString(arr1);
	}

	public static void main(String[] args) {
		int num;
		String result;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no. of elements in String:");
		num = sc.nextInt();
		System.out.println("Enter String you want to sort:");
		String arr[] = new String[num];
		for (int i = 0; i < num; i++) {
			arr[i] = sc.next();
		}
		result = getSortedString(arr);
		System.out.println("Sorted String:\t" + result);
		sc.close();
	}

}
