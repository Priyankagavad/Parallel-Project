package capgemini.labbook3;

import java.util.Arrays;
import java.util.Scanner;

public class Lab3_Ex3_ReverseArray {

	static int[] getSorted(int[] arr) {

		int[] arr1 = new int[arr.length];
		for (int index = 0; index < arr.length; index++) {
			int n = arr[index], digit = 0, reverse = 0;
			while (n != 0) {
				digit = n % 10;
				reverse = reverse * 10 + digit;
				n = n / 10;
			}
			arr1[index] = reverse;
		}
		Arrays.sort(arr1);
		return arr1;
	}

	public static void main(String[] args) {
		int num;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no. of elements:");
		num = sc.nextInt();
		System.out.println("Enter numbers you want to sort:");
		int arr[] = new int[num];
		for (int i = 0; i < num; i++) {
			arr[i] = sc.nextInt();

		}
		System.out.println("Reversed array" + Arrays.toString(getSorted(arr)));
		sc.close();
	}

}
