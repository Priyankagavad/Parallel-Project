package capgemini.labbook3;

import java.util.Scanner;

public class Lab3_Ex4_CountCharacter {

	public static void countCharacter(char[] arr) {

		char[] visited = new char[arr.length];
		int[] count = new int[arr.length];
		int i = 0, j = 0;
		boolean flag = false;
		for (i = 0; i < arr.length; i++) {
			for (j = 0; j < i; j++) {
				if (arr[i] == arr[j]) {
					flag = true;
					break;
				}
			}
			if (flag == false) {
				visited[i] = arr[i];
				count[i]++;
			} else if (flag == true) {
				count[j]++;
			}
		}
		for (int x = 0; x < count.length; x++) {
			if (count[x] > 0) {
				System.out.println(arr[x] + " : " + count[x]);
			}
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no of characters:");
		int n = sc.nextInt();
		char[] arr = new char[n];
		System.out.println("Enter characters:");
		for (int i = 0; i < n; i++) {
			arr[i] = sc.next().charAt(0);
		}
		countCharacter(arr);
		sc.close();
	}

}
