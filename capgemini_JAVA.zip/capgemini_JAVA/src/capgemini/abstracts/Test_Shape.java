package capgemini.abstracts;

abstract class Shape {

	public Shape() {
		super();
		System.out.println("Shape->def.......");
	}

	public void draw() {
		System.out.println("Shape is drawn.......");
	}

	public abstract double calcArea();

	@Override
	public String toString() {
		return "Shape:->";
	}
}

class Circle extends Shape {
	// field....
	float radius;

	// default constructor.....
	public Circle() {
		super(); // will call deafault costructor of shape class
		System.out.println("Circle->def...");
	}

	// parameter constructor...
	public Circle(float radius) {
		super(); // will call default constructor of shape class
		this.radius = radius;
	}

	@Override
	public void draw() {
		super.draw();
		System.out.println("Circle is draw.....");
	}

	@Override
	public double calcArea() {
		return radius * radius * Math.PI;
	}

	// toString....
	@Override
	public String toString() {
		// super.toString() will call toString from shape class
		return super.toString() + "circle [radius=" + radius + "]";
	}

	// equals
	
	public boolean equals (Object obj){
		public void showCircle() {
			System.out.println("I am circle");
		}
	}
}

public class Test_Shape {
	public static void main(String[] args) {
		// Shape shape;
		// shape = new Shape(); //Shape cannot be instantiated, it is abstract
		Circle c1 = new Circle(2.0f);
		c1.draw();
		c1.calcArea();
		c1.showCircle();
		
		Shape shape = new Circle();
		shape.draw();
		shape.calcArea();
		shape.showCircle();
		
	}
}
