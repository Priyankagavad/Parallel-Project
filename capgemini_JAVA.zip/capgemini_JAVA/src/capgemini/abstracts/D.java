package capgemini.abstracts;

import java.util.Arrays;
import java.util.List;

public class D {

	public static void main(String[] args) {
		List<String> list = Arrays.asList("25","225","1000","20","15");
		list.stream().mapToLong(num->Long.parseLong(num)).filter(num->Math.sqrt(num)/5==3).forEach(System.out::println);
		System.out.println((225)/5==3);

	}

}
