package capgemini.labbook10;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Lab10_Ex1_CopyDataThread extends Thread {

	public String input, output;

	public Lab10_Ex1_CopyDataThread(String input, String output) {
		super();
		this.input = input;
		this.output = output;
	}

	public void run() {
		File inpfile = new File(input);
		File outfile = new File(output);
		System.out.println("Copying");

		try {
			FileInputStream fi = new FileInputStream(input);
			FileOutputStream fo = new FileOutputStream(output);

			int i = 0;
			int c = 1;
			while (i != -1) {
				while (c != 10) {
					if (i == -1)
						break;
					fo.write(i);
					i = fi.read();
					c++;
				}
				c = 0;
				System.out.println("10 characters are copied");
				Thread.sleep(5000);
			}
			System.out.println("Copied ");

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
