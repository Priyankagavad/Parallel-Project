package capgemini.labbook10;

import java.util.Scanner;

public class Lab10_Ex1_FileProgram {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		String input = sc.next();
		String output = sc.next();

		Thread t = new Lab10_Ex1_CopyDataThread(input, output);
		t.start();
		sc.close();
	}

}
