package capgemini.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class Query_Test {

	public static void main(String[] args) {

		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521/xe";
			String username = "INVENTORY1";
			String password = "INVENTORY1";

			Connection connection = DriverManager.getConnection(url, username, password);

			Statement stat = connection.createStatement();

			// Creating static query
			String SQL = "SELECT * FROM DIRECTOR";
			ResultSet rs = stat.executeQuery(SQL);

			// retrieving table structure
			ResultSetMetaData rsmd = rs.getMetaData();
			int colCount = rsmd.getColumnCount();
			for (int index = 1; index < colCount; index++) {
				String colName = rsmd.getColumnName(index);
				String colType = rsmd.getColumnTypeName(index);
				System.out.println(colName + ":" + colType);
			}

			// process the result
			while (rs.next()) {
				int dirNumber = rs.getInt("DIRECTOR_NUMBER");
				String dirName = rs.getString("DIRECTOR_NAME");
				System.out.println(dirNumber + ":" + dirName);
			}

			rs.close();
			stat.close();
			connection.close();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
}
