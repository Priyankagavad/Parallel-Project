package capgemini.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import oracle.jdbc.driver.OracleDriver;

public class jdbc_Test {

	public static void main(String[] args) {
		// 1. Download JDBC driver for oracle
		// 2. Copy to lib folder and add to build path
		try {
			// 3. Load the JDBC Driver
			Class.forName("oracle.jdbc.driver.OracleDriver");

			// 4. Create Connection
			Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe", "INVENTORY1",
					"INVENTORY1");

			// 5. Create statement for SQL query...
			Statement stat = connection.createStatement();

			// 6. Execute the query...
			String SQL = "SELECT * FROM CUSTOMER";
			ResultSet rs = stat.executeQuery(SQL);

			// 7. Process the result
			while (rs.next()) {
				System.out.println(rs.getString("first_name"));
			}

			// 8. Close the database resources
			rs.close();
			stat.close();
			connection.close();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
