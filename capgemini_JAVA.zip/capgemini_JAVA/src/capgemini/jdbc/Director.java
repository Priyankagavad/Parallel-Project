package capgemini.jdbc;

public class Director {

	private int dirNumber;
	private String dirName;
	
	public Director() {
		super();
	}
	
	public Director(int dirNumber, String dirName) {
		super();
		this.dirNumber = dirNumber;
		this.dirName = dirName;
	}
	
	public int getDirNumber() {
		return dirNumber;
	}
	
	public void setDirNumber(int dirNumber) {
		this.dirNumber = dirNumber;
	}
	
	public String getDirName() {
		return dirName;
	}
	
	public void setDirName(String dirName) {
		this.dirName = dirName;
	}
	
	@Override
	public String toString() {
		return String.format("Director [dirNumber=%s, dirName=%s]", dirNumber, dirName);
	}
	
	
}
