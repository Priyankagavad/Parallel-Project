package capgemini.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class Query_Test2 {

	public static void main(String[] args) {

		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521/xe";
			String username = "INVENTORY1";
			String password = "INVENTORY1";

			Connection connection = DriverManager.getConnection(url, username, password);
			connection.setAutoCommit(false);
			Statement stat = connection.createStatement();

			// Creating static query
			String SQL = "INSERT INTO DIRECTOR VALUES(?, ?)";

			PreparedStatement pstat = connection.prepareStatement(SQL);
			int dirNumber = 5;
			String dirName = "Amar";

			pstat.setInt(1, dirNumber);
			pstat.setString(2, dirName);

			int rows = pstat.executeUpdate();
			System.out.println(rows + " inserted .....");

			// commit the transaction
			connection.commit();

			// Close the database resources
			pstat.close();
			connection.close();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
}
