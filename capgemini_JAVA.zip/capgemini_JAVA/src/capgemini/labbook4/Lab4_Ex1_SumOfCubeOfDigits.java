package capgemini.labbook4;

import java.util.Scanner;

public class Lab4_Ex1_SumOfCubeOfDigits {

	public static int calculateSum(int n) {
		int digit = 0, sum = 0;
		while (n != 0) {
			digit = n % 10;
			sum = sum + (digit * digit * digit);
			n = n / 10;
		}
		return sum;

	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number:");
		int n = sc.nextInt();
		int sum = calculateSum(n);
		System.out.println("sum of the cubes of the digits of an" + n + "digit number is" + sum);
		sc.close();
	}

}
