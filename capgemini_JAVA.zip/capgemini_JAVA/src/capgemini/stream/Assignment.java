package capgemini.stream;

public class Assignment {

	public static void main(String[] args) {
		
		String[] arr = new String[10];
		
	}
}
