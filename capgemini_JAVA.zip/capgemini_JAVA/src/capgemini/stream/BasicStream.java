package capgemini.stream;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class BasicStream {

	public static void main(String[] args) {

		Integer[] arr = new Integer[10];
		for (int i = 0; i < arr.length; i++) {
			arr[i] = (int) (Math.random() * 100);
		}

		arr = new Integer[] { 1, 2, 3, 4, 5, 5, 4, 3, 2, 1 };

		// obtaining a stream
		Stream<Integer> stream = Arrays.stream(arr);

		// consumer -> lambda expression
		// stream.forEach((value) -> System.out.println(value));

		// stream cannot be used again
		// Method reference
		// stream.forEach(System.out::println);

		// stream cannot be used again
		// distinct() -> intermediate operation & forEach() -> terminal
		// operation
		// stream.distinct().forEach(System.out::println);

		// stream cannot be used again
		// stream.distinct().limit(3).forEach(System.out::println);

		// stream cannot be used again
		// print odd numbers only.....
		// Predicate<Integer> oddPredicate = (value) -> value % 2 != 0;
		// stream.filter(oddPredicate).forEach(System.out::println);

		// stream cannot be used again
		// print min
		// stream.sorted().limit(1).forEach(System.out::println);

		// stream cannot be used again
		// print max
		Comparator<Integer> comp = (num1, num2) -> (num1 > num2 ? 1 : num2 > num1 ? -1 : 0);
		Optional<Integer> optionalMax = stream.max(comp);
		System.out.println(optionalMax.get());
	}
}
