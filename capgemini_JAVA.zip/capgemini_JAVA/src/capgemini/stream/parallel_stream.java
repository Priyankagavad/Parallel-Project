package capgemini.stream;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class parallel_stream {

	public static void main(String[] args) {

		List<String> cities = new ArrayList<>();
		cities.add("Pune");
		cities.add("Bangalore");
		cities.add("Pune");
		cities.add("Chennai");

		// cities.parallelStream().forEach(System.out::println);

		// cities.stream().distinct().forEach(city -> System.out.println(city));

		// List<String> collect =
		// cities.stream().distinct().collect(Collectors.toList());
		// System.out.println(collect);

		// List<String> collect1 = cities.stream().collect(Collectors.toList());
		// System.out.println(collect1);

		Set<String> collect2 = cities.stream().collect(Collectors.toSet());
		System.out.println(collect2);
	}
}
