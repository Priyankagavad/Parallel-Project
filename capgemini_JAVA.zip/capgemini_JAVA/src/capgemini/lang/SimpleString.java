package capgemini.lang;

public class SimpleString {
	public static void main(String[] args) {
		String s1 = "JAVA";
		String s2 = "JAVA";
		String s3 = new String("JAVA");

		// char[] value = new char[] {'J', 'A', 'V', 'A' };
		char[] value = { 'J', 'A', 'V', 'A' };
		String s4 = new String(value);
		String s5 = new String(s4);

		if (s1 == s2) {
			// values are same & memory location are also same
			System.out.println("s1 == s2");
		}

		if (s1 != s3) {
			// values are same but different memory location
			System.out.println("s1 != s2");
		}

		System.out.println("Length of String s2 : " + s2.length());

		System.out.println("Index of v : " + s2.indexOf('v'));

		System.out.println("s2 in uppercase : " + s2.toUpperCase());

		System.out.println("s2 in uppercase : " + s2.toLowerCase());

		System.out.println("Character at position 2 is  : " + s2.charAt(1));

		System.out.println("String concatenatiion:" + s1.concat("\tFundamentals"));

		System.out.println("string ends with the specified suffix:" + s3.endsWith("JAVA"));

		System.out.println("Bytes of string s5" + s5.getBytes());

		System.out.println("Index of string s4" + s4.indexOf(s3));

		System.out.println("Is s1 string is empty or not" + s1.isEmpty());

		System.out.println("Tests if this string starts with the specified prefix" + s3.startsWith("J"));

		System.out.println("Converts s2 string to a new character array" + s2.toCharArray());
	}

}
