package capgemini.lang;
import capgemini.javabeans.Employee;
public class MySystem {
	
	public static void main(String[] args) {
	System system;
	// system = new System();    //cannot be instantiated
	
	long startMemory = Runtime.getRuntime().freeMemory();
	long startTimeMilliS = System.currentTimeMillis();
	
	System.out.println("Start Memory:" + startMemory);
	System.out.println("start Time:" + startTimeMilliS);
	
	// consuming memory
	for(int index=0; index < 100000; index++){
		new Employee();
	}
	System.out.println("Last employee ID:" + Employee.SEQUENCE);
	System.out.println("Total employee count:" +Employee.COUNT);
	
	long endMemory = Runtime.getRuntime().freeMemory();
	long endTimeMilliS = System.currentTimeMillis();
	
	System.out.println("End Memory:" + endMemory);
	System.out.println("End Time:" + endTimeMilliS);
	
}
}
