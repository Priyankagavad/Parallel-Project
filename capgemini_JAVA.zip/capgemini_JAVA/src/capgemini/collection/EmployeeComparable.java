package capgemini.collection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class Employee implements Comparable<Employee> {

	private int empID;
	private String name;

	public Employee(int empID, String name) {
		this.empID = empID;
		this.name = name;
		System.out.println("I am in a parameter constructor.....");
	}

	public int getEmpID() {
		return empID;
	}

	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return String.format("Employee [empID=%s, name=%s]", empID, name);
	}

	@Override
	public int compareTo(Employee otherEmployee) {
		if (empID == otherEmployee.getEmpID())
			return 0;
		else if (empID > otherEmployee.getEmpID())
			return 1;
		else
			return -1;
	}
}

class NameComparator implements Comparator<Employee> {
	public int compare(Employee e1, Employee e2) {
		if (e1.getName().equals(e2.getName()))
			return 0;
		else
			return 1;
	}
}

public class EmployeeComparable {
	public static void main(String[] args) {
		Employee e1, e2, e3;
		e1 = new Employee(101, "abc");
		e3 = new Employee(102, "pqr");
		e2 = new Employee(103, "xyz");

		Employee[] emps = { e1, e3, e2 };
		Arrays.sort(emps);
		System.out.println("Array sorted via Arrays.sort:" + Arrays.toString(emps));

		List<Employee> list = new ArrayList<Employee>();
		list.add(e1);
		list.add(e2);
		list.add(e3);
		System.out.println("Size:" + list.size() + "\t" + list);
		
		Collections.sort(list, new NameComparator());
		System.out.println("ArrayList sorted via Colellections.sort:" + list);
		
		Collections.sort(list);
		System.out.println("ArrayList sorted via Colellections.sort:" + list);
	}

}
