package capgemini.collection;

import java.util.Iterator;
import java.util.TreeSet;

public class _TreeSet {
	public static void main(String[] args) {
		TreeSet<String> treeset = new TreeSet<String>();
		System.out.println("size:" + treeset.size() + "\t" + treeset);

		// treeset.add(null); // not allowed
		treeset.add("A");
		treeset.add("A"); // duplicate value is not allowed
		treeset.add("C"); // insertion order is not maintained
		treeset.add("B");
		System.out.println("size:" + treeset.size() + "\t" + treeset);

		// iterating
		Iterator<String> iterator = treeset.iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		
		System.out.println("Printing in descending order...");
		Iterator<String> descendingIterator = treeset.descendingIterator();
		while (descendingIterator.hasNext()) {
			System.out.println(descendingIterator.next());
		}
	}
}
