package capgemini.collection;

import java.util.HashMap;

public class Test_AccountHashMap {

	public static void main(String[] args) {
		HashMap<Integer, Account> map_Account = new HashMap<Integer, Account>();

		// creating account
		Account account1 = new Account("Allen", 5000); // 101-5000
		Account account2 = new Account("Boston", 8000); // 102-8000
		Account account3 = new Account("Chappel", 10000); // 103-10000

		// adding account to map
		map_Account.put(account1.getAccountNo(), account1);
		map_Account.put(account2.getAccountNo(), account2);
		map_Account.put(account3.getAccountNo(), account3);

		// printing all accounts from map
		map_Account.values().forEach((account) -> System.out.println(account));

		// Account - Allen ->depositing 2000
		if (map_Account.containsKey(101)) {
			Account accountAllen = map_Account.get(101);
			double currentBalance = accountAllen.getCurrentBalance();
			currentBalance = currentBalance + 2000; // deposit 2000 & update the
													// balance
			accountAllen.setCurrentBalance(currentBalance);
			System.out.println("Allen Account: " + accountAllen); // 101 - 7000
		}

		// Funds Transfer - Chappel-103 to Boston-102 -> transfer 1000
		Account accountBoston=null, accountChappel=null;

		if (map_Account.containsKey(102)) {
			accountBoston = map_Account.get(102);
		}
		if (map_Account.containsKey(103)) {
			accountChappel = map_Account.get(103);
		}
		double currentBalanceBoston = accountBoston.getCurrentBalance();
		double currentBalanceChappel = accountChappel.getCurrentBalance();

		currentBalanceBoston += 1000;
		currentBalanceChappel -= 1000;

		// update balance Chappel
		accountChappel.setCurrentBalance(currentBalanceChappel);

		// update balance Boston
		accountBoston.setCurrentBalance(currentBalanceBoston);

		// printing all accounts from map
		map_Account.values().forEach(System.out::println); // 101-7000, // 102-9000, // 103-9000
															
		}
}
