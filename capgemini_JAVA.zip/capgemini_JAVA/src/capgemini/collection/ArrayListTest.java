package capgemini.collection;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListTest {
	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<String>();
		String str = "hi";
		list.add("String");
		list.add(str);
		list.add(str + str);
		System.out.println(list.size());
		System.out.println(list.contains("hihi"));
		list.remove("hi");
		System.out.println(list.size());

		// index based
		for (int index = 0; index < list.size(); index++)
			System.out.println(list.get(index));

		// enhanced for loop
		for (Object object : list)
			System.out.println(object);

		// iterator based
		Iterator<String> iterator = list.iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}

	}
}
