package capgemini.collection;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class Test_HashMap {

	public static void main(String[] args) {
		HashMap<Integer, String> weekDays = new HashMap<Integer, String>();

		weekDays.put(1, "Monday");
		weekDays.put(2, "Tuesday");
		weekDays.put(3, "Wednesday");
		weekDays.put(4, "Thursday");
		weekDays.put(5, "Friday");
		weekDays.put(6, "Saturday");
		weekDays.put(7, "Sunday");
		System.out.println(weekDays.size() + "\t" + weekDays);

		boolean containsKey = weekDays.containsKey(5);
		boolean containsValue = weekDays.containsValue("Friday");
		System.out.println("Contains Key: " + containsKey);
		System.out.println("Contains Value: " + containsValue);

		String day = weekDays.get(5);
		System.out.println("Printing -> weekDays.get");
		System.out.println("Day: " + day);

		weekDays.remove(5);
		System.out.println(weekDays.size() + "\t" + weekDays);

		weekDays.put(5, "Friday");
		System.out.println(weekDays.size() + "\t" + weekDays);

		// printing key:value
		System.out.println("Printing using forEach");
		weekDays.forEach((key, value) -> System.out.println(key + ":" + value));

		// printing key
		System.out.println("Printing -> weekDays.keySet");
		Set<Integer> keySet = weekDays.keySet();
		keySet.forEach((key) -> System.out.println(key + " "));

		// printing value
		System.out.println("Printing -> weekDays.values");
		Collection<String> values = weekDays.values();
		values.forEach(System.out::print);

		Set<Entry<Integer, String>> entrySet = weekDays.entrySet();
		Iterator<Entry<Integer, String>> iterator = entrySet.iterator();
		System.out.println("\nPrinting -> weekDays.entrySet");
		while (iterator.hasNext()) {
			Entry<Integer, String> entry = iterator.next();
			System.out.println("Key: " + entry.getKey() + ":" + "Value:" + entry.getValue());
		}

	}
}
