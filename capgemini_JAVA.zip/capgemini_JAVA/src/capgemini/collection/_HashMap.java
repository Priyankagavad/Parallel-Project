package capgemini.collection;

import java.util.HashMap;
import java.util.Iterator;

public class _HashMap {
	public static void main(String[] args) {
		HashMap<Integer, String> hashmap = new HashMap<Integer, String>();
		System.out.println("size:" + hashmap.size() + "\t" + hashmap);

		hashmap.put(null, null); // allows only one null key
		hashmap.put(null, null);
		hashmap.put(0, null); // allows many null values
		hashmap.put(1, "Mon");
		hashmap.put(1, "Jan"); // duplicate keys are not allowed
		hashmap.put(2, "Feb");
		hashmap.put(3, "Mar");
		System.out.println("size:" + hashmap.size() + "\t" + hashmap);

		// hashmap.iterator(); do not give iterator directly...
		Iterator<Integer> itrKeys = hashmap.keySet().iterator();
		while (itrKeys.hasNext()) {
			System.out.println(itrKeys.next());
		}

		System.out.println("Printing key values.......");
		Iterator<Integer> itrKeys2 = hashmap.keySet().iterator();
		System.out.println("Printing keys.......");
		while (itrKeys2.hasNext()) {
			Integer key = itrKeys2.next();
			System.out.println(key + ":" + hashmap.get(key));
		}
	}
}
