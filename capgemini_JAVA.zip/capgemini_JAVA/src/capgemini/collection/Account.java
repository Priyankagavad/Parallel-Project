package capgemini.collection;

public class Account {
	
	static int ACCOUNT_NUMBER_SEQUENCE=100;
	private String accountName;;
	private int accountNo;
	private double openingBalance;
	private double currentBalance;
	
	public Account(String accountName, double openingBalance) {
		super();
		ACCOUNT_NUMBER_SEQUENCE++;
		setAccountName(accountName);
		setAccountNo(ACCOUNT_NUMBER_SEQUENCE);
		setOpeningBalance(openingBalance);
		setCurrentBalance(openingBalance);
	
	}

	public static int getACCOUNT_NUMBER_SEQUENCE() {
		return ACCOUNT_NUMBER_SEQUENCE;
	}

	public static void setACCOUNT_NUMBER_SEQUENCE(int aCCOUNT_NUMBER_SEQUENCE) {
		ACCOUNT_NUMBER_SEQUENCE = aCCOUNT_NUMBER_SEQUENCE;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public double getOpeningBalance() {
		return openingBalance;
	}

	public void setOpeningBalance(double openingBalance) {
		this.openingBalance = openingBalance;
	}

	public double getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(double currentBalance) {
		this.currentBalance = currentBalance;
	}

	@Override
	public String toString() {
		return String.format("Account [accountName=%s, accountNo=%s, openingBalance=%s, currentBalance=%s]",
				accountName, accountNo, openingBalance, currentBalance);
	}
}
