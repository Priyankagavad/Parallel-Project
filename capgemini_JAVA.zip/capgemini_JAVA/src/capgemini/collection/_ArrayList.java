package capgemini.collection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Vector;

public class _ArrayList {
	public static void main(String[] args) {
		// ArrayList<String> list = new ArrayList<String>(3);
		// LinkedList<String> list = new LinkedList<String>();
		Vector<String> list = new Vector<String>();
		System.out.println("Size:" + list.size() + "\t" + list);
		// list.add("Sun"); duplicates are allowed
		// list.add("null");multiple nulls are allowed
		// list.add("null");
		list.add("Sun");
		list.add("Mon");
		list.add("Wed");
		System.out.println("Size:" + list.size() + "\t" + list);

		// added based on index
		list.add(2, "Tue");
		System.out.println("Size:" + list.size() + "\t" + list);

		list.add("Thus");
		list.add("Free");
		list.add("Sat");
		list.add("Soon");
		System.out.println("Size:" + list.size() + "\t" + list);

		int index = list.indexOf("Free");
		if (index != -1) {
			list.set(index, "Fri");
		}
		if (list.contains("Free")) {
			list.set(list.indexOf("Free"), "Fri");
		}

		// searched a string
		if (list.contains("Free"))
			list.set(5, "Fri"); // modified a value
		System.out.println("Size:" + list.size() + "\t" + list);

		if (list.contains("Soon"))
			list.set(7, "Sun"); // modified a value
		System.out.println("Size:" + list.size() + "\t" + list);

		// iterating
		Iterator<String> iterator = list.iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}

		// enhanced for loop
		for (String value : list) {
			System.out.println(value);
		}

	}
}
