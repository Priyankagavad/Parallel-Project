package capgemini.collection;

public class BoxingUnboxing {
	public static void main(String[] args) {
		int _int  = 10;
		Integer _intobj = new Integer(10);
		
		_int = _intobj;   // object type is assigned to primitive type
		_intobj = _int;   // primitive type is assigned to object type
		
		// before JDK 1.5 - explicit type conversion was needed
		// object type is converted & assigned to primitive type
		_int = _intobj.intValue();
		
		// integer type is converted & assigned to object type
		_intobj = Integer.valueOf(_int);
	}

}
