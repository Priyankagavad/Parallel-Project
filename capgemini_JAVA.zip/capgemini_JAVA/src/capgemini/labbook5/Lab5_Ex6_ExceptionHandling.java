package capgemini.labbook5;

import java.util.Scanner;

import com.cg.eis.exception.EmployeeException;

public class Lab5_Ex6_ExceptionHandling {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Salary");
		int Salary = sc.nextInt();

		try {
			if (Salary <= 3000) {
				throw new EmployeeException("Salary of an Employee is below 3000");
			} else {
				System.out.println("Salary of an Employee is greater than 3000");
			}
		} catch (EmployeeException e) {
			System.out.println(e);
		}
		sc.close();
	}
}
