package capgemini.labbook5;

import java.util.Scanner;

public class Lab5_Ex2_Fibonacciseries {

	public static void main(String[] args) {
		int n1 = 1, n2 = 1, n3 = 0, n;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number:");
		n = sc.nextInt();
		System.out.print(n1);
		System.out.print("\n" + n2 + "\n");
		// Non Recursive solution
		for (int i = 0; i < n - 2; i++) {
			n3 = n1 + n2;
			n1 = n2;
			n2 = n3;
			System.out.println("" + n3);
		}
		System.out.print("nth number in fibonacci series is\t" + n3 + "\n");
		sc.close();

		// Recursive solution
		int result = 0;
		result = fibonacci(n - 2);
		System.out.print("nth number in fibonacci series is\t" + result);
	}

	static int n3 = 1, n4 = 1, n5;

	public static int fibonacci(int n) {

		if (n > 0) {
			n5 = n3 + n4;
			n3 = n4;
			n4 = n5;
			System.out.println("" + n5);
			fibonacci(n - 1);
		}
		return n5;
	}

}
