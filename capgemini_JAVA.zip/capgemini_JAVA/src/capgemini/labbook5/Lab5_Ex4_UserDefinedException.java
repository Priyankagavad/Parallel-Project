package capgemini.labbook5;

import java.util.Scanner;

public class Lab5_Ex4_UserDefinedException {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter first name:");
		String firstName = sc.nextLine();
		System.out.println("Enter last name:");
		String lastName = sc.nextLine();

		try {

			if (firstName.isEmpty() && lastName.isEmpty()) {
				System.out.println("Please recheck the input");
				throw new BadUserInputException("Name cannot contain empty spaces\n");
			} else if (firstName.contains(" ") && lastName.contains(" ")) {
				throw new BadUserInputException("Name cannot be empty\n");
			} else {
				System.out.println("Name is correct");
			}
		} catch (BadUserInputException e) {
			System.out.println(e);
		}
	}
}

class BadUserInputException extends Exception {

	public BadUserInputException(String message) {
		System.out.print(message);

	}
}
