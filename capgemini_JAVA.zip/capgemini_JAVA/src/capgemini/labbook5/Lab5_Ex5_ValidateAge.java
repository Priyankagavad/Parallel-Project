package capgemini.labbook5;

import java.util.Scanner;

public class Lab5_Ex5_ValidateAge {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your age:");
		int age = sc.nextInt();

		try {
			if (age <= 15) {
				throw new AgeException("Invalid age");
			} else {
				System.out.println("valid age");
			}
		} catch (AgeException e) {
			System.out.println(e);
		}
		sc.close();
	}
}

@SuppressWarnings("serial")
class AgeException extends Exception {
	public AgeException(String str) {
		System.out.println(str);
	}
}