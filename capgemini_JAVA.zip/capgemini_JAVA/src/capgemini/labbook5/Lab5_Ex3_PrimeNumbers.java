package capgemini.labbook5;

import java.util.Scanner;

public class Lab5_Ex3_PrimeNumbers {
	public static void primeNumber(int n) {
		for (int i = 1; i <= n; i++) {
			int count = 0;
			for (int j = 1; j <= n; j++) {
				if (i % j == 0) {
					count++;
				}
			}
			if (count == 2) {
				System.out.println("Prime number\t" + i);
			}
		}
	}

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number:");
		int n = sc.nextInt();
		primeNumber(n);
		sc.close();

	}
}
