package capgemini.concurrent;

//import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Executor_Test_1 {

	public static void main(String[] args) {
		System.out.println("Inside:" + Thread.currentThread().getName());

		System.out.println("Creating Executor Service with single worker thread");
		//Executor executor = Executors.newSingleThreadExecutor();
		ExecutorService executorService = Executors.newSingleThreadExecutor();

		System.out.println("Creating a Runnable....");
		Runnable task = new Runnable() {
			public void run() {
				System.out.println("Inside:" + Thread.currentThread().getName());

			}
		};

		System.out.println("Submit the task specified by the runnable to the executor");
		//executor.execute(task);
		 executorService.submit(task);

		System.out.println("shutting down the executor");
		executorService.shutdown();
	}
}
