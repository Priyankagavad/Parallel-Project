package capgemini.contactbook;

import java.util.Scanner;

public class ContactOperationImpl_Main1 {

	public static void main(String[] args) {
		ContactOperation contactOperation = new ContactOperationImpl(3);

		int choice = 0;

		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("Welcome to Contact Book...");
			System.out.println("1.Add Contact");
			System.out.println("2.Delete Contact");
			System.out.println("3.Find Contact");
			System.out.println("4.List All");
			System.out.println("5.Exit");
			System.out.println("Enter Choice");
			choice = sc.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Enter first name");
				String firstName = sc.next();

				System.out.println("Enter last name");
				String lastName = sc.next();

				System.out.println("Enter email ID");
				String email = sc.next();

				System.out.println("Enter phone no");
				String phoneNo = sc.next();
				Contact contact = new Contact(firstName, lastName, email, phoneNo);
				contactOperation.addContact(contact);
				System.out.println("\t\t::->contact is created......");
				break;

			case 2:
				System.out.println("Enter first name");
				firstName = sc.next();
				contactOperation.deleteContact(firstName);
				System.out.println("\t\t::->contact is deleted......");
				break;

			case 3:
				System.out.println("Enter first name");
				firstName = sc.next();
				contact = contactOperation.findContact(firstName);
				System.out.println(contact);
				break;

			case 4:
				contactOperation.listAll();
				break;

			}
		} while (choice != 4);
		sc.close();

	}
}
