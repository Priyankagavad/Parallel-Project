package capgemini.contactbook;

import java.util.Scanner;

public class ContactOperationImpl_Main {

	public static void main(String[] args) {
		ContactOperation contactOperation = new ContactOperationImpl(3);

		int choice = 0;
		Scanner sc = new Scanner(System.in);
			do {
			System.out.println("Welcome to Contact Book...");
			System.out.println("1.Add Contact");
			System.out.println("2.Delete Contact");
			System.out.println("3.Find Contact");
			System.out.println("4.List All");
			System.out.println("5.Exit");
			System.out.println("Enter Choice");
			choice = sc.nextInt();

			switch (choice) {
			case 1:
				Contact contact = new Contact("Vikram", "Das", "vikramdas123@gmail.com", "9876564324");
				contactOperation.addContact(contact);
				System.out.println("\t\t::->contact is created......");
				break;

			case 2:
				contactOperation.deleteContact("Vikram");
				break;

			case 3:
				contact = contactOperation.findContact("Vikram");
				System.out.println(contact);
				break;

			case 4:
				contactOperation.listAll();
				break;

			}
		} while (choice != 4);
		sc.close();

	}
}
