package capgemini.contactbook;

public interface ContactOperation {
	abstract public void addContact(Contact contact);
    abstract public void deleteContact(String firstName);
	abstract public Contact findContact(String firstName);
	abstract public void listAll();
}

