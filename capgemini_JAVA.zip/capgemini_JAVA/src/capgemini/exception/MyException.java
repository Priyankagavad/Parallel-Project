package capgemini.exception;

import javax.sound.midi.SysexMessage;

// java MyException 10 a
//java MyException 10 0
public class MyException {
	
	static int div1(int no1, int no2){
		// unhandled exception type exception
		try{
			if(no2 <= 0) throw new Exception("no2 has a value:" +no2);
		}catch(Exception ex){
			System.err.println("cannot divide by zero");
		}
		return no1/no2;
	}
	
	static int div2(int no1, int no2) throws Exception{
		if(no2 <= 0) throw new Exception("n02 has a value:" +no2);
		return no1/no2;
	}
	
	static int div3(int no1, int no2) throws DivisionException{
		if(no2 <= 0) throw new DivisionException("n02 has a value:" +no2);
		return no1/no2;
	}
	public static void main(String[] args) {
		System.out.println("start.....");
		if (args.length < 2) {
			System.out.println("Please provide 2 arguments");
			System.exit(0);
		}

		int no1, no2, result;
		no1 = no2 = result = 0;
		try {
			no1 = Integer.parseInt(args[0]);
			no2 = Integer.parseInt(args[1]);
			result = div3(no1, no2);
			System.out.println("Result\t" + result);
		} catch (NumberFormatException ex) {
			System.err.println("Please provide two numeric arguments");
			// ex.printStackTrace();
		} catch (ArithmeticException ex) {
			System.err.println("Please provide 2nd non zero numeric argument");
		}catch (Exception ex){
			System.err.println("exception occured in div2....." + ex.getMessage());
		}
		finally {
			System.out.println("I will reach in any conditions");
		}
		System.out.println("end....");

	}
}
