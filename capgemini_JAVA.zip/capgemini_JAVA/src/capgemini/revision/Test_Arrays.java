package capgemini.revision;

import java.util.Arrays;

public class Test_Arrays {

	public static void main(String[] args) {
		// int arrays definition/declaration
		int[] nums;
		String[] names;
		
		// memory allocation 
		nums = new int[5];
		names = new String[3];
		
		//assign values to elements\
		names[0] = "Amar";
		names[1] = "Rohan";
		names[2] = "Nikita";
		
		System.out.println(Arrays.toString(nums));
		System.out.println(Arrays.toString(names));
		
	}
}
