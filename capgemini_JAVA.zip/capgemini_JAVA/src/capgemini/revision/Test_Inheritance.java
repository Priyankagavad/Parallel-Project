package capgemini.revision;

public class Test_Inheritance {

	public static void main(String[] args) {
		Word w;
		w = new Word("Application");
		System.out.println(w.toString());
		w.open();
		w.close();
		w.read();
		w.write();

		Excel e;
		e = new Excel("Application");
		System.out.println(e.toString());
		e.open();
		e.close();
		e.read();
		e.write();

		Powerpoint p;
		p = new Powerpoint("Application");
		System.out.println(p.toString());
		p.open();
		p.close();
		p.read();
		p.write();
	}
}

abstract class Document {
	String text;

	public Document() {
		text = "Document";
	}

	public Document(String text) {
		this.text = text;
	}

	void open() {
		System.out.println("opening....");
	}

	void read() {
		System.out.println("Reading.........");
	}

	void write() {
		System.out.println("writing.......");
	}

	void close() {
		System.out.println("Closing.....");
	}

	public String toString() {
		return "Document->text:" + text;
	}
}

class Word extends Document {

	public Word() {
		super("Word Document........");
		System.out.println("Word def.......");
	}

	public Word(String text) {
		super(text);
		System.out.println("word parameter....");
	}

	@Override
	void open() {
		System.out.println("opening word....");
	}

	@Override
	void read() {
		System.out.println("Reading word.........");
	}

	@Override
	void write() {
		System.out.println("writing word.......\n");
	}

	@Override
	void close() {
		System.out.println("Closing word.....");
	}

	@Override
	public String toString() {
		return super.toString() + "\tWord: " + text;
	}

}

class Excel extends Document {

	public Excel() {
		super("Excel Document........");
		System.out.println("Excel def.......");
	}

	public Excel(String text) {
		super(text);
		System.out.println("Excel parameter....");
	}

	@Override
	void open() {
		System.out.println("opening excel....");
	}

	@Override
	void read() {
		System.out.println("Reading excel.........");
	}

	@Override
	void write() {
		System.out.println("writing excel.......\n");
	}

	@Override
	void close() {
		System.out.println("Closing excel.....");
	}

	@Override
	public String toString() {
		return "Excel: " + text;
	}

}

class Powerpoint extends Document {

	public Powerpoint() {
		super("Powerpoint  Document........");
		System.out.println("Powerpoint def.......");
	}

	public Powerpoint(String text) {
		super(text);
		System.out.println("Powerpoint  parameter....");
	}

	@Override
	void open() {
		System.out.println("opening powerpoint....");
	}

	@Override
	void read() {
		System.out.println("Reading powerpoint.........");
	}

	@Override
	void write() {
		System.out.println("writing powerpoint.......");
	}

	@Override
	void close() {
		System.out.println("Closing poerpoint.....");
	}

	@Override
	public String toString() {
		return "Powerpoint: " + text;
	}

}
