package capgemini.revision;

public class Test_class {

	public static void main(String[] args) {
		float sum = 0;
		Product p1, p2;
		p1 = new Product();
		p1.setProdId(1);
		p1.setName("xyz");
		p1.setCost(45.5f);

		p2 = new Product(2, "pqr", 34.5f);
		System.out.println("Product Id: " + p1.getProdId());
		System.out.println("Product Name: " + p1.getName());
		System.out.println("Product Cost: " + p1.getCost());

		System.out.println(p2.toString());

		if (p1.equals(p2))
			System.out.println(true);
		else
			System.out.println(false);

		// object arrays...........or products
		Product[] arr = new Product[5];
		arr[0] = new Product(1, "xyz", 34.6f);
		arr[1] = new Product(2, "pqr", 56.4f);
		arr[2] = new Product(3, "vbf", 54.3f);
		arr[3] = new Product(4, "dfg", 67.5f);
		arr[4] = new Product(5, "sdf", 56.4f);
		for (int i = 0; i < arr.length; i++) {
			sum = sum + arr[i].getCost();
		}
		System.out.println("\n Sum=" + sum);
	}
}

class Product {
	// Fields
	private int prodId;
	private String name;
	private float cost;

	// Default Constructor
	public Product() {
		setProdId(0);
		setName(null);
		setCost(0.0f);
	}

	// Parameter Constructor
	public Product(int prodId, String name, float cost) {
		setProdId(prodId);
		setName(name);
		setCost(cost);
	}

	// getter/setter methods
	public void setProdId(int prodId) {
		this.prodId = prodId;
	}

	public int getProdId() {
		return prodId;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setCost(float cost) {
		this.cost = cost;
	}

	public float getCost() {
		return cost;
	}

	@Override
	public String toString() {
		return "Product Id: " + getProdId() + " Product Name: " + getName() + " Product Cost: " + getCost();
	}

	@Override
	public boolean equals(Object obj) {
		// type casting object to product
		Product otherProduct = (Product) obj;
		if (prodId == otherProduct.getProdId() && name.equals(otherProduct.getName()) && cost == otherProduct.getCost())
			return true;
		else
			return false;

	}

}
