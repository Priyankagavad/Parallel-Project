package capgemini.revision;


interface Printer{
	public void print(Document doc);
}

public class Test_Interface {

	public static void main(String[] args) {
		Word word = new Word("MS Word");
		Excel excel = new Excel("MS Excel");
		HP_Printer printer = new HP_Printer();
		printer.print(word);
		printer.print(excel);
		System.out.println(printer.getCOUNT());
	}
}

class HP_Printer implements Printer{
	
	private static int COUNT = 0;
	@Override
	public void print(Document doc) {
		HP_Printer.COUNT+=1;
		System.out.println(doc);
		
	}
	
	public int getCOUNT(){
		return COUNT;
	}
	
}
