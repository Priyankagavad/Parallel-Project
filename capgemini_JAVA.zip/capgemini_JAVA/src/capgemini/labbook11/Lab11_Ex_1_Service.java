package capgemini.labbook11;

public class Lab11_Ex_1_Service {

}
