package capgemini.labbook1;

import java.util.Scanner;

public class Lab1_Ex1_CalculateSum {

	static int calculateSum(int n) {
		int sum = 0;
		for (int i = 1; i <= n; i++) {
			if (i % 3 == 0 || i % 5 == 0) {
				sum = sum + i;

			}
		}
		return sum;
	}

	public static void main(String[] args) {
		int sum = 0, n;
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();
		sum = calculateSum(n);
		System.out.println("Sum:" + sum);
		sc.close();
	}

}
