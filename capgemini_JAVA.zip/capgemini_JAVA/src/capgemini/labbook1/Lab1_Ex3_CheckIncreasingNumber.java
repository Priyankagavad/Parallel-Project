package capgemini.labbook1;

import java.util.Scanner;

public class Lab1_Ex3_CheckIncreasingNumber {

	static boolean checkNumber(int number) {
		int rem = 0;
		boolean result = false;
		rem = number % 10;
		number = number / 10;
		while (number > 0) {
			if (rem > number % 10) {
				result = true;
			}
			rem = number % 10;
			number = number / 10;
		}
		return result;
	}

	public static void main(String[] args) {
		int number;
		boolean result;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number:\t");
		number = sc.nextInt();
		result = checkNumber(number);
		System.out.println("Whether the number is increasing number:\t" + result);
		sc.close();
	}

}
