package capgemini.labbook1;

import java.util.Scanner;

public class Lab1_Ex4_CheckPowerOfTwo {

	static boolean checkNumber(int n) {
		boolean result;
		if (n % 2 == 0) {
			result = true;
		} else {
			result = false;
		}
		return result;
	}

	public static void main(String[] args) {
		int n;
		boolean result;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number:\t");
		n = sc.nextInt();
		result = checkNumber(n);
		System.out.println(" Number is power of 2:\t" + result);
		sc.close();

	}

}
