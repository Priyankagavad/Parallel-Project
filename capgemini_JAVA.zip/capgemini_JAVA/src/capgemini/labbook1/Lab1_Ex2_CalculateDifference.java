package capgemini.labbook1;

import java.util.Scanner;

public class Lab1_Ex2_CalculateDifference {

	static int calculateDifference(int n) {
		int sum = 0, sum1 = 0, sum2 = 0;
		for (int i = 1; i <= n; i++) {
			sum1 = sum1 + i * i;
			System.out.println("Sum1:" + sum1);
			sum2 = sum2 + i;
			System.out.println("Sum2:" + sum2);
		}
		sum = sum1 - (sum2) * (sum2);
		return sum;
	}

	public static void main(String[] args) {
		int sum = 0, n;
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();
		sum = calculateDifference(n);
		System.out.println("Sum:" + sum);
		sc.close();
	}

}
