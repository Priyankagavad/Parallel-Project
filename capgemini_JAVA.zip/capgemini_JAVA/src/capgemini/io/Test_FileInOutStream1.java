package capgemini.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Test_FileInOutStream1 {
	public static void main(String[] args) {
		fileInputStream_2();
	}
	
	// autocloseable interface
	public static void fileInputStream_2(){
		File file;
		FileInputStream fileInput = null;
		file = new File("C:\\capgemini\\readme.txt");

		try {
			fileInput = new FileInputStream(file);
			int input = 0;

			while ((input = fileInput.read()) != -1) {
				System.out.print((char) input);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
