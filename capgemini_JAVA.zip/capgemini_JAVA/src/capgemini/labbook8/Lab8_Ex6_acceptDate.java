package capgemini.labbook8;

import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class Lab8_Ex6_acceptDate {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter year: ");
		int year = sc.nextInt();
		System.out.println("Enter month: ");
		int month = sc.nextInt();
		System.out.println("Enter day: ");
		int day = sc.nextInt();
		LocalDate date1 = LocalDate.now();
		LocalDate date2 = LocalDate.of(year, month, day);
		Period diff = Period.between(date2, date1);
		System.out.println("Duration in years with respect to current system date: " + diff.getYears());
		System.out.println("Duration in months with respect to current system date: " + diff.getMonths());
		System.out.println("Duration in days with respect to current system date: " + diff.getDays());
		sc.close();
	}
}
