package capgemini.labbook8;

import java.util.Arrays;
import java.util.Scanner;

public class Lab8_Ex5_FileHandling3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter string: ");
		String str = sc.next();
		boolean result = checkPositiveOrNot(str);
		System.out.println("Given string is positive: " + result);
		sc.close();
	}

	private static boolean checkPositiveOrNot(String str) {
		int n = str.length();
		boolean result = false;
		char[] c;
		c = new char[n];
		for (int i = 0; i < n; i++) {
			c[i] = str.charAt(i);
		}
		Arrays.sort(c);
		for (int i = 0; i < n; i++) {

			if (c[i] != str.charAt(i)) {
				result = false;
			} else {
				result = true;
			}
		}
		return result;
	}

}
