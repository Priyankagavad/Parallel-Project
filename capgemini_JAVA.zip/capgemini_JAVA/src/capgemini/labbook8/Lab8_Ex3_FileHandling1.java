package capgemini.labbook8;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Lab8_Ex3_FileHandling1 {

	public static void main(String[] args) throws FileNotFoundException {
		File file;
		file = new File("C:\\capgemini\\readme.txt");
		Scanner inputFile = new Scanner(file);

		int lineNumber = 0, chars = 0, charCount = 0, words = 0;
		while (inputFile.hasNext()) {
			// to count lines
			String line = inputFile.nextLine();
			lineNumber++;

			// to count characters
			String c = line;
			chars = c.length();
			charCount = charCount + chars;

			// to count words
			StringTokenizer st = new StringTokenizer(line);
			words = words + st.countTokens();
		}
		System.out.println(lineNumber);
		System.out.println(charCount);
		System.out.println(words);
		inputFile.close();

	}
}
