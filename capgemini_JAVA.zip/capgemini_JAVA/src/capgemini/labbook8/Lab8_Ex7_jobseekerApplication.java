package capgemini.labbook8;

import java.util.Scanner;

public class Lab8_Ex7_jobseekerApplication {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter username: ");
		String str = sc.next();
		boolean result = validateUsername(str);
		System.out.println("Name is valid: " + result);
		sc.close();
	}

	private static boolean validateUsername(String str) {
		int n = str.length();
		System.out.println(n);
		boolean r = false;
		if (n >= 8) {
			String str1 = str.substring(n-4, n);
			if (str1.equals("_job")) {
				r = true;
			} else {
				r = false;
			}
		}
		return r;

	}
}
