package capgemini.labbook8;

import java.io.File;
import java.nio.file.Files;
import java.util.Scanner;

public class Lab8_Ex4_FileHandling2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter file name:");
		String inputFile = sc.next();
		String fileType = "Undetermined";
		File file = new File(inputFile);

		System.out.println("File Exists:" + file.exists());
		System.out.println("File Readable:" + file.canRead());
		System.out.println("File Writable:" + file.canWrite());
		System.out.println("File Type:" + getFileExtension(fileType));
		System.out.println("File Size:" + file.length());

	}

	public static String getFileExtension(String fileType) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter file name:");
		String inputFile = sc.next();
		String fileName = new File(inputFile).getName();
		int dotIndex = fileName.lastIndexOf('.');
		return inputFile = fileName.substring(dotIndex + 1);
	}
}
