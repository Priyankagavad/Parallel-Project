package capgemini.labbook8;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Lab8_Ex2_FileHandling {

	public static void main(String[] args) throws FileNotFoundException {
		File file;
		file = new File("C:\\capgemini\\readme.txt");
		Scanner inputFile = new Scanner(file);

		int lineNumber = 1;
		while (inputFile.hasNext()) {
			String line = inputFile.nextLine();
			System.out.println(lineNumber + ":" + line);
			lineNumber++;
		}
		inputFile.close();

	}

}
