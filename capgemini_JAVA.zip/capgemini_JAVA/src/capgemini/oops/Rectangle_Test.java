package capgemini.oops;

class Rectangle {
	// field.....
	float length, breadth;

	// constructors.....
	public Rectangle() {
		length = 0.0f;
		breadth = 0.0f;
		System.out.println("rectangle def.....");
	}

	// constructor overloading.........
	public Rectangle(float plength, float pbreadth) {
		length = plength;
		breadth = pbreadth;
		System.out.println("Rectangle-> parameter.....");
	}

	// methods........
	public void draw() {
		System.out.println("rectangle is drawn....");
	}

	// methods.......
	public double calcArea() {
		return length * breadth * Math.PI;
	}

	// method overriding from parent object class
	@Override // java annotation
	public String toString() {
		return "Length:" + length + "\tBreadth:" + breadth;
	}

	// if(r1.equals(r2)){
	@Override
	public boolean equals(Object obj) {
		Rectangle otherRectangle = (Rectangle) obj;
		if (this.length == otherRectangle.length && this.breadth == otherRectangle.breadth) {
			return true;
		} else {
			return false;
		}
	}
}

public class Rectangle_Test {
	public static void main(String[] args) {
		// Declaration...
		Rectangle r1, r2;

		// Object Instantiation
		r1 = new Rectangle(3.0f, 3.0f);
		r2 = new Rectangle(4.0f, 5.0f);

		// calling instance methods..........
		r1.draw();
		System.out.println("r1 area:" + r1.calcArea());

		r2.draw();
		System.out.println("r2 area:" + r2.calcArea());

		System.out.println(r1);
		System.out.println(r2.toString());

		if (r1.equals(r2)) {
			System.out.println("r1 equals r2");
		} else {
			System.out.println("r1 not equals r2");
		}

	}

}
