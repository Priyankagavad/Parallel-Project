package capgemini.oops;

class Circle{
	// field.....
	float radius;
	
	// constructors.........
	public Circle(){
		radius = 0.0f;
		System.out.println("circle->def........");
	}
	
	// constructor overloading.........
	public Circle(float pradius){
		radius = pradius;
		System.out.println("circle-> parameter.....");
	}
	
	// methods........
	public void draw(){
		System.out.println("circle is drawn....");
		}
	
	public double calcArea(){
		return radius*radius*Math.PI;
		}
	
	// method overriding from parent object class
	@Override       // java annotation
	public String toString(){
		return "Radius:" +radius;
		
	}

//if(c1.equals(c2)){
	@Override
	public boolean equals(Object obj){
		Circle otherCircle = (Circle) obj;
		if(this.radius == otherCircle.radius){
			return true;
		}
		else{
			return false;
		}
	}
}
		
public class Circle_Test {
	
	public static void main(String[] args) {
		// Declaration...
		Circle c1, c2;
		
		// Object Instantiation
		c1 = new Circle();
		c2 = new Circle(5.5f);
		
		System.out.println("****Object array****");
		// Array of Objects
		// declaration
		Circle[] circles;
		
		// initialization
		circles = new Circle[2];
		circles[0] = new Circle(5.5f);
		circles[1] = new Circle(8.5f);
		
		for(int index=0; index < circles.length; index++){
			circles[index].draw();
			System.out.println(circles[index].calcArea());
		}
		
		
		// calling instance methods..........
		c1.draw();
		System.out.println("c1 area:" +c1.calcArea());
		
		c2.draw();
		System.out.println("c2 area:" +c2.calcArea());
		
		System.out.println(c1);
		System.out.println(c2.toString());
		
	
	if(c1.equals(c2)){
		System.out.println("c1 equals c2");
	}
	else{
		System.out.println("c1 not equals to c2");
	}
	}

}


