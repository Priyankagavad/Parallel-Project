package capgemini.oops;

class Student {
	// fields
	int rollNo;
	String name;
	float marks;

	final float OUT_OF_MARKS = 300;

	// constructor
	public Student() {
		rollNo = 0;
		name = null;
		marks = 0.0f;
	}

	// constructor overloading
	public Student(int rollNo, String name, float marks) {
		this.rollNo = rollNo;
		this.name = name;
		this.marks = marks;
	}

	// methods...........
	public void display() {
		System.out.println("Roll No:" + rollNo);
		System.out.println("Name:" + name);
		System.out.println("Marks:" + marks);
	}

	public double calcPercentage() {
		return (marks * 100) / OUT_OF_MARKS;
	}

	public String calcGrade() {
		double percentage = calcPercentage();
		if (percentage < 40) {
			return "Fail";
		} else if (percentage > 40 && percentage <= 60) {
			return "C";
		} else if (percentage > 60 && percentage <= 75) {
			return "B";
		} else {
			return "A";
		}
	}

	// method overriding from parent object class
	@Override // java annotation
	public String toString() {
		return "RollNo:" + rollNo + "\tName:" + name + "\tMarks:" + marks;

	}
	
	// if(s1.equals(s2))
	@Override
	public boolean equals(Object obj) {
		Student otherStudent=(Student) obj;
		if(this.marks==otherStudent.marks){
			return true;
		}
		return super.equals(obj);
	}
}

public class Student_Test {
	public static void main(String[] args) {
		// declaration.........
		Student s1, s2;

		// object instantiation.....
		s1 = new Student(4, "xyz", 200);
		s2 = new Student(6, "pqr", 200);

		System.out.println(s1);

		// calling instance methods...
		s1.display();
		System.out.println("Percentage" + s1.calcPercentage());
		System.out.println("Grade" + s1.calcGrade());

		s2.display();
		System.out.println("Percentage" + s1.calcPercentage());
		System.out.println("Grade" + s2.calcGrade());
		
		if (s1.equals(s2)) {
			System.out.println("s1 equals s2");
		} else {
			System.out.println("s1 not equals s2");
		}

	}

}
