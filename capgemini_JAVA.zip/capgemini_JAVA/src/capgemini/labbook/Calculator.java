package capgemini.labbook;

public class Calculator {
	
	static int add(int no1, int no2){
		return no1+no2;
	}
	
	static int sub(int no1, int no2){
		return no1-no2;
	}
	
	static int mult(int no1, int no2){
		return no1*no2;
	}
	
	static int div(int no1, int no2){
		return no1/no2;
	}
	public static void main(String[] args) {
		int no1,no2,result;
		no1=10;
		no2=5;
		result=add(no1,no2);
		System.out.println("add:"+result);
		
		result=sub(no1,no2);
		System.out.println("sub:"+result);
		
		result=mult(no1,no2);
		System.out.println("mult:"+result);
		
		result=div(no1,no2);
		System.out.println("div:"+result);
	}

}
