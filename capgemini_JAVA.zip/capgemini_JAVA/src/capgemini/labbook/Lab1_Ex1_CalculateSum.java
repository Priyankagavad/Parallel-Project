package capgemini.labbook;

import java.util.Scanner;

public class Lab1_Ex1_CalculateSum {
	
	public static int CalculateSum(int n) {
		int sum=0;
		for(int i=1; i<=n; i++){
			sum=sum+i;
		}
		return sum;
	}
	public static void main(String[] args) {
		int sum=0,n;
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		sum=CalculateSum(n);
		System.out.println("Sum:"+sum);
	}

}
