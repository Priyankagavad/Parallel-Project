package capgemini.labbook9;

import java.util.HashMap;
import java.util.Scanner;

public class Lab9_Ex2_CountCharacter {

	private static void charCount(char[] a) {
		HashMap<Character, Integer> charCountMap = new HashMap<Character, Integer>();
		for (char c : a) {
			if (charCountMap.containsKey(c)) {
				charCountMap.put(c, charCountMap.get(c) + 1);
			} else {
				charCountMap.put(c, 1);
			}
		}
		System.out.println(charCountMap);

	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("First add some characters...");
		char[] a = sc.next().toCharArray();
		charCount(a);
		sc.close();
	}
}
