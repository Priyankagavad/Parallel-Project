package capgemini.java8.functional;

public class Item {
 
	private int itemId;
	private String Name;
	private float cost;
	
	public Item() {
		super();
	}
	public Item(int itemId, String name, float cost) {
		super();
		this.itemId = itemId;
		Name = name;
		this.cost = cost;
	}
	
	@Override
	public String toString() {
		return String.format("Item [itemId=%s, Name=%s, cost=%s]", itemId, Name, cost);
	}
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public float getCost() {
		return cost;
	}
	public void setCost(float cost) {
		this.cost = cost;
	}
	
}
