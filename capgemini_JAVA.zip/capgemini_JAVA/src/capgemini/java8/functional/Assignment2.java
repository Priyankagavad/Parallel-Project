package capgemini.java8.functional;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;



public class Assignment2 {

	public static void main(String[] args) {
		List<String> weekDays = Arrays.asList("Sun", "Mon", "Tue", "Wed");
		System.out.println("Natural Order:" + weekDays);

		Collections.sort(weekDays);
		System.out.println("Ascending Order:" + weekDays);

		/*
		 * Using anonymous class
		Comparator<String> descComparator = new Comparator<String>() {
			@Override
			public int compare(String str1, String str2) {
				return str2.compareTo(str1);
			}

		};
		Collections.sort(weekDays, descComparator);
		System.out.println("Descending Order:" + weekDays);
		*/
		
		// Comparator -> lambda expression
		//Comparator<String> descComparator = (String str1, String str2) -> {
		//		return str2.compareTo(str1);
		//};
		
		//Collections.sort(weekDays, descComparator);
		//System.out.println("Descending Order:" + weekDays);

		// printAsc(weekDays, descComparator);
		printAsc(weekDays, (String str1, String str2) ->
			{return str2.compareTo(str1);}
		);
		
		// forEach
		// Lambda usage in iteration of collection
		for(String day:weekDays){
			System.out.println(day);
		}
		
		// to forEach
		// passing Consumer interface implementation as Lambda Expression
		weekDays.forEach((day) -> System.out.print(day));
		
		// Passing Consumer interface implementation as Method Reference
		weekDays.forEach();
}
	private static void printAsc(List<String> weekDays, Comparator<String> descComparator){
		Collections.sort(weekDays, descComparator);
		System.out.println("Descending Order:" + weekDays);

	}
}
