package capgemini.java8.functional;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Test_LambdaExpression {

	public static void main(String[] args) {
		
		/*
		Runnable runnable = new Runnable(){
			@Override
			public void run() {
				System.out.println("Runnable.....");
			}
		};
		Thread t = new Thread(runnable);
		t.start();
		
		Callable<String> callable = new Callable<String>(){
			@Override
			public String call() throws Exception {
				System.out.println("Callable......");
				return "Callable Done";
			}
		};
		ExecutorService executorService = Executors.newSingleThreadExecutor();
		executorService.submit(callable);
		executorService.shutdown();
		*/
		
		// Implement Runnable -> Lambda Expression
		Runnable runnable1 = () ->System.out.println("Runnable.....");
		Thread lambdaThread1 = new Thread(runnable1);
		lambdaThread1.start();
		
		//passing implementation as function argument
		//Thread lambdaThread1 = new Thread(() ->System.out.println("Runnable....."));
		// lambdaThread1.start();
		
		// Implement Callable -> Lambda Expression
		Callable<String> callable = () -> {
				System.out.println("Callable......");
				return "Callable Done";
		};
		ExecutorService executorService = Executors.newSingleThreadExecutor();
		executorService.submit(callable);
		executorService.shutdown();
		
	}
}
