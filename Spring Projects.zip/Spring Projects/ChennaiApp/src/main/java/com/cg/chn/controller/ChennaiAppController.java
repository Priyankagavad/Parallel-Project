package com.cg.chn.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ChennaiAppController {

	@RequestMapping("/greet")
	public String sayHello() {
		return "Welcome to Spring Boot";
	}
}
