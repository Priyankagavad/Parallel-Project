package org.cg.chn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChennaiAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChennaiAppApplication.class, args);
	}

}
