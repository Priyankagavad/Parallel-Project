package com.cg.sharetrading.exception;

// User defined exception
public class StockException extends Exception {

	public StockException() {
		super();
	}

	public StockException(String msg) {
		super(msg);
	}
}
