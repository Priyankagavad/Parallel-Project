package com.cg.sharetrading.service;

import java.util.List;

import com.cg.sharetrading.bean.Stock;
import com.cg.sharetrading.exception.StockException;

//service class interface which contains method declaration
public interface StockService {

	List<Stock> calculateOrder(Stock bean) throws StockException;

	List<Stock> getAllStockTradingDetails() throws StockException;

	List<Stock> updateStockTradingDetails(Stock bean) throws StockException;

	List<Stock> deleteStockDetailsById(int id) throws StockException;

	Stock getStockTradingDetailsById(int id) throws StockException;
}
