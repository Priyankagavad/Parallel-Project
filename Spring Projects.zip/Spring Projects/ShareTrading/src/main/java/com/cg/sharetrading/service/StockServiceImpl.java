package com.cg.sharetrading.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.sharetrading.bean.Stock;
import com.cg.sharetrading.dao.StockRepo;
import com.cg.sharetrading.exception.StockException;

// Implementation of StockService class Methods
@Service
public class StockServiceImpl implements StockService {

	@Autowired
	private StockRepo stockRepo;
	double brokerage;

	@Override
	public List<Stock> calculateOrder(Stock bean) throws StockException {
		try {
			if (stockRepo.existsById(bean.getId()));
		} catch (Exception e) {
			throw new StockException(e.getMessage());
		}
		double amount = bean.getPrice() * bean.getQuantity();

		if (bean.getQuantity() > 100) {
			brokerage = ((0.3) / 100) * amount;
		} else {
			brokerage = ((0.5) / 100) * amount;
		}
		bean.setBrokerage(brokerage);
		bean.setAmount(amount);
		stockRepo.save(bean);
		return getAllStockTradingDetails();
	}

	@Override
	public List<Stock> getAllStockTradingDetails() throws StockException {
		try {
			return stockRepo.findAll();
		} catch (Exception e) {
			throw new StockException(e.getMessage());
		}
	}

	@Override
	public List<Stock> updateStockTradingDetails(Stock bean) throws StockException {
		if (stockRepo.existsById(bean.getId())) {
			int tempId = bean.getId();
			Stock tempBean = stockRepo.findById(tempId).get();
			tempBean.setPrice(bean.getPrice());
			tempBean.setQuantity(bean.getQuantity());
			double amount = tempBean.getPrice() * tempBean.getQuantity();
			if (tempBean.getQuantity() > 100) {
				brokerage = ((0.3) / 100) * amount;
			} else {
				brokerage = ((0.5) / 100) * amount;
			}
			tempBean.setBrokerage(brokerage);
			tempBean.setAmount(amount);
			stockRepo.save(tempBean);
			return getAllStockTradingDetails();
		}
		throw new StockException("Stock with ID " + bean.getId() + " does not exist");
	}

	@Override
	public List<Stock> deleteStockDetailsById(int id) throws StockException {
		if (stockRepo.existsById(id)) {
			stockRepo.deleteById(id);
			return getAllStockTradingDetails();
		}
		throw new StockException("Stock with ID " + id + " does not exist");
	}

	@Override
	public Stock getStockTradingDetailsById(int id) throws StockException {
		if (stockRepo.existsById(id)) {
			return stockRepo.findById(id).get();
		}
		throw new StockException("Stock with ID " + id + " does not exist");
	}

}
