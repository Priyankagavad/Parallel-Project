package com.cg.sharetrading.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.sharetrading.bean.Stock;

// StockRepo interface uses JpaRepository
@Repository
public interface StockRepo extends JpaRepository<Stock, Integer> {

}
