package com.cg.sharetrading.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.sharetrading.bean.Stock;
import com.cg.sharetrading.exception.StockException;
import com.cg.sharetrading.service.StockService;

@RestController
public class StockController {

	@Autowired
	private StockService stockService;

	// Controller method to view all stock details using service
	@RequestMapping("/ViewAllStock")
	public List<Stock> getAllStockTradingDetails() throws StockException {
		return stockService.getAllStockTradingDetails();
	}

	// Controller method to create stock using service
	@PostMapping("/CreateStock")
	public List<Stock> calculateOrder(@Valid @RequestBody Stock bean) throws StockException {
		return stockService.calculateOrder(bean);
	}

	// Controller method to update stock details using service
	@PutMapping("/UpdateStock")
	public List<Stock> updateStockTradingDetails(@Valid @RequestBody Stock bean) throws StockException {
		return stockService.updateStockTradingDetails(bean);
	}

	// Controller method to delete stock using service
	@DeleteMapping("/DeleteStock/{id}")
	public List<Stock> deleteStockDetailsById(@PathVariable int id) throws StockException {
		return stockService.deleteStockDetailsById(id);
	}

	// Controller method to get stock by id using service
	@GetMapping("/FindSingleStock/{id}")
	public Stock getStockTradingDetailsById(@PathVariable int id) throws StockException {
		return stockService.getStockTradingDetailsById(id);
	}
}
