package com.cg.student.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.student.beans.Student;
import com.cg.student.dao.StudentRepository;
import com.cg.student.exception.StudentException;

@Service
public class StudentServiceImpl implements StudentService {

	
	@Autowired
	private StudentRepository studentRepository; 
	
	@Override
	public List<Student> addStudent(Student stud) throws StudentException {
		try {
			if(studentRepository.existsById(stud.getId()));
		} catch (Exception e) {
			throw new StudentException(e.getMessage());
		} 
		studentRepository.save(stud);
		return getAllStudents();
	}

	@Override
	public List<Student> updateStudent(Student stud) throws StudentException {
		if(studentRepository.existsById(stud.getId())) {
			studentRepository.save(stud);
			return getAllStudents();
		}
		throw new StudentException("Student with ID " +stud.getId()+ " does not exist");
	}

	@Override
	public List<Student> deleteStudent(int id) throws StudentException {
		if(studentRepository.existsById(id)) {
			studentRepository.deleteById(id);
			return getAllStudents();
		}
		throw new StudentException("Student with ID " +id+ " does not exist");
	}

	@Override
	public List<Student> getAllStudents() throws StudentException {
		try {
			return studentRepository.findAll();
		} catch (Exception e) {
			throw new StudentException(e.getMessage());
		}
	}

	@Override
	public List<Student> getStudentsByStream(String stream) throws StudentException {
		 return studentRepository.findByStream(stream);
	}

}
