package com.cg.student.service;

import java.util.List;

import com.cg.student.beans.Student;
import com.cg.student.exception.StudentException;

public interface StudentService {

	List<Student> addStudent(Student stud) throws StudentException;
	List<Student> updateStudent(Student stud) throws StudentException;
	List<Student> deleteStudent(int id) throws StudentException;
	List<Student> getAllStudents() throws StudentException;
	List<Student> getStudentsByStream(String stream) throws StudentException;
}
