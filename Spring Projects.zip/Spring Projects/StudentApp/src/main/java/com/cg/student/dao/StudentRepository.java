package com.cg.student.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.student.beans.Student;

@Repository
public interface StudentRepository extends JpaRepository<Student, Integer> {
	
	@Query("from Student where stream=:stream")
	List<Student> findByStream(@RequestParam String stream);
}
