package org.cg.emp.service;

import java.util.List;

import org.cg.emp.beans.Employee;
import org.cg.emp.dio.EmployeeRepository;
import org.cg.emp.exception.EmployeeException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ExceptionHandler;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	private EmployeeRepository employeeRepository; 
	
	@Override
	public List<Employee> getAllEmployees() throws EmployeeException {
		
		try {
			return employeeRepository.findAll();
		} catch (Exception e) {
			throw new EmployeeException(e.getMessage());
		}
	}

	@Override
	public List<Employee> addEmployee(Employee emp) throws EmployeeException {
		try {
			if(employeeRepository.existsById(emp.getId()));
		} catch (Exception e) {
			throw new EmployeeException(e.getMessage());
		}
		employeeRepository.save(emp);
		return getAllEmployees();
	}

	@Override
	public Employee getEmployeeById(int id) throws EmployeeException {
		
		if(!employeeRepository.existsById(id)) {
			throw new EmployeeException("Employee with Id " +id+ "does not exist");
		}
		return employeeRepository.findById(id).get();
	}

	@Override
	public List<Employee> deleteEmployee(int id) throws EmployeeException {
		if(!employeeRepository.existsById(id)) {
			throw new EmployeeException("Employee with Id " +id+ " does not exist");
		}
		employeeRepository.deleteById(id);
		return getAllEmployees();
	}

	@Override
	public List<Employee> updateEmployee(Employee emp) throws EmployeeException {
		if(employeeRepository.existsById(emp.getId())) {
			employeeRepository.save(emp);
			return getAllEmployees();
		}
		throw new EmployeeException("Employee with Id " +emp.getId()+ "does not exist");
	}

	@Override
	public List<Employee> getEmployeeByGender(String gender) throws EmployeeException {
		return employeeRepository.findEmployeeByGender(gender);
	}

	
}
