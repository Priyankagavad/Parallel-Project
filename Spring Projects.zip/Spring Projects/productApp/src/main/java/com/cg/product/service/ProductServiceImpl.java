package com.cg.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.product.beans.Product;
import com.cg.product.dao.ProductRepository;
import com.cg.product.exception.ProductException;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepository productRepository;
	
	@Override
	public List<Product> addProduct(Product prod) throws ProductException {
		productRepository.save(prod);
		return getAllProductDetails();
	}

	@Override
	public List<Product> updateProduct(Product prod) throws ProductException {
		if(productRepository.existsById(prod.getId())) {
			int tempId = prod.getId();
			Product tempProd = productRepository.findById(tempId).get();
			tempProd.setPrice(prod.getPrice());
			tempProd.setQuantity(prod.getQuantity());
			productRepository.save(tempProd);
			return getAllProductDetails();
		}
		throw new ProductException("Product with Id " +prod.getId()+ " does not exist");
	}

	@Override
	public List<Product> getAllProductDetails() throws ProductException {
		try {
			return productRepository.findAll();
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
	}

	@Override
	public List<Product> deleteProduct(int id) throws ProductException {
		if(!productRepository.existsById(id)) {
			throw new ProductException("Product with Id " +id+ " does not exist");
		}
		productRepository.deleteById(id);
		return getAllProductDetails();
	}

	@Override
	public Product getProductById(int id) throws ProductException {
		if(!productRepository.existsById(id)) {
			throw new ProductException("Product with Id " +id+ " does not exist");
		}
		 return productRepository.findById(id).get();
		
	}

	@Override
	public List<Product> getProductByCategory(String category) throws ProductException {
		return productRepository.findProductByCategory(category);
	}

}
