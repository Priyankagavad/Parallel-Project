package com.cg.session.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.session.beans.Session;
import com.cg.session.dao.SessionRepository;
import com.cg.session.exception.SessionException;

@Service
public class SessionServiceImpl implements SessionService{

	
	@Autowired
	private SessionRepository sessionRepository; 
	
	@Override
	public List<Session> addSessionDetails(Session session) throws SessionException {
		try {
			if(sessionRepository.existsById(session.getCourseId()));
		} catch (Exception e) {
			throw new SessionException(e.getMessage());
		}
		sessionRepository.save(session);
		return getAllSessionDetails();
	}

	@Override
	public List<Session> updateSessionDetails(Session session) throws SessionException {
		if(sessionRepository.existsById(session.getCourseId())) {
			sessionRepository.save(session);
			return getAllSessionDetails();
		}
		throw new SessionException("Session with course id " +session.getCourseId()+ " does not exist");
	}

	@Override
	public List<Session> deleteSessionDetails(int courseId) throws SessionException {
		if(!sessionRepository.existsById(courseId)) {
			throw new SessionException("Session with course id " +courseId+ " does not exist");
		}
		sessionRepository.deleteById(courseId);
		return getAllSessionDetails();
	}

	@Override
	public List<Session> getAllSessionDetails() throws SessionException {
		try {
			return sessionRepository.findAll();
		} catch (Exception e) {
			throw new SessionException(e.getMessage());
		}
	}

	@Override
	public Session getSessionById(int courseId) throws SessionException {
		if(!sessionRepository.existsById(courseId)) {
			throw new SessionException("Session with course id " +courseId+ " does not exist");
		}
		return sessionRepository.findById(courseId).get();
	}

	@Override
	public List<Session> getSessionByMode(String mode) throws SessionException {
		return sessionRepository.findSessionByMode(mode);
	}

}
