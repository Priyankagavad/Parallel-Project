package com.cg.session.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.session.beans.Session;
import com.cg.session.exception.SessionException;
import com.cg.session.service.SessionService;

@RestController
public class SessionController {

	@Autowired
	private SessionService sessionService;
	
	@PostMapping("/session")
	public List<Session> addSessionDetails(@RequestBody Session session) throws SessionException{
		return sessionService.addSessionDetails(session);
	}
	
	@RequestMapping("/session")
	public List<Session> getAllSessionDetails() throws SessionException{
		return sessionService.getAllSessionDetails();
	}
	
	@PutMapping("/session/update")
	public List<Session> updateSessionDetails(@RequestBody Session session) throws SessionException {
		return sessionService.updateSessionDetails(session);
	}
	
	@DeleteMapping("/session/{courseId}")
	public List<Session> deleteSessionDetails(@PathVariable int courseId) throws SessionException{
		return sessionService.deleteSessionDetails(courseId);
	}
	
	@GetMapping("/session/{courseId}")
	public Session getSessionById(@PathVariable int courseId) throws SessionException {
		return sessionService.getSessionById(courseId);
	}
	
	@GetMapping("/session/mode")
	public List<Session> getSessionByMode(@RequestParam String mode) throws SessionException{
		return sessionService.getSessionByMode(mode);
	}
}
