package com.cg.session.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

@Entity
@Table(name="Course")
public class Session {

	@Id
	 private int courseId;

     private String courseName;

     private String faculty;

     @Min(3)
     private int duration;

     @Pattern(regexp="online|classroom", message="mode type should be online or classroom")
     @Column(name="modeType")
     private String mode;

	public int getCourseId() {
		return courseId;
	}

	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getFaculty() {
		return faculty;
	}

	public void setFaculty(String faculty) {
		this.faculty = faculty;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	@Override
	public String toString() {
		return "Session [courseId=" + courseId + ", courseName=" + courseName + ", faculty=" + faculty + ", duration="
				+ duration + ", mode=" + mode + "]";
	}

	
     
     
}
