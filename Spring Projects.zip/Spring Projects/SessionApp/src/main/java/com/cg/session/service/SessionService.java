package com.cg.session.service;

import java.util.List;

import com.cg.session.beans.Session;
import com.cg.session.exception.SessionException;

public interface SessionService {

	List<Session> addSessionDetails(Session session) throws SessionException;
	List<Session> updateSessionDetails(Session session) throws SessionException;
	List<Session> deleteSessionDetails(int courseId) throws SessionException;
	List<Session> getAllSessionDetails() throws SessionException;
	Session getSessionById(int courseId) throws SessionException;
	List<Session> getSessionByMode(String mode) throws SessionException;
}
