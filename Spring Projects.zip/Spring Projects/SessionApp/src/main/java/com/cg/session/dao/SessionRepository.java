package com.cg.session.dao;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.session.beans.Session;


@Repository
public interface SessionRepository extends JpaRepository<Session, Integer> {

	@Query("from Session where mode=:mode")
	List<Session> findSessionByMode(@Param("mode") String mode);
}
