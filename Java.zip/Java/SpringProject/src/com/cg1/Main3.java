package com.cg1;

import java.util.Locale;

import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main3 {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring1.xml");
		
		/*String msg = context.getMessage("greeting", null, "Default greeting", null);
		System.out.println(msg);*/
		
		/*Circle1 c = (Circle1) context.getBean("circle1");
		c.draw();*/
		
		MessageSource s = (MessageSource) context.getBean("messageSource");
		Locale locale = new Locale("in", "Kn");
		String msg = s.getMessage("welcome.message", null, "Default Message", locale);
		System.out.println(msg);
	}
}
