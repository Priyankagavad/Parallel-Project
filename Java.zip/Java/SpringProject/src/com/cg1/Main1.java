package com.cg1;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


import com.cg.Triangle;

public class Main1 {
	
	public static void main(String[] args) {
		
		// XML configuration
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("spring1.xml");
		context.registerShutdownHook();
		
		/*Employee e = context.getBean("employee", Employee.class);
		System.out.println(e.getDob());*/
		
		Circle1 c = (Circle1) context.getBean("cir");
		c.draw();
		System.out.println("Done successfully");
	}
}
