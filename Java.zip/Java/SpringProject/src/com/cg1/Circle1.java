package com.cg1;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import com.cg.Point;

@Component    //.....................bean instant is automatically created
public class Circle1 {
	
	@Autowired
	//@Resource(name="point2")
	private Point center;
	
	
	@Autowired
	MessageSource messageSource;
	
	
	
	public MessageSource getMessageSource() {
		return messageSource;
	}

	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

	public Point getCenter() {
		return center;
	}
	
	//@Required
	public void setCenter(Point center) {
		this.center = center;
	}
	 public void draw(){
		 String m = messageSource.getMessage("greeting", null, "Default Greet", null);
		 System.out.println(m);
		 System.out.println(messageSource.getMessage("circle.drawing", null, "No Drawing", null));
		 System.out.println(messageSource.getMessage("circle.points", new Object[]{center.getX(),center.getY()}, "No Points", null));
		 
		 //System.out.println("Circle Points("+center.getX()+","+center.getY()+")");
	 }
	 
	 @PostConstruct
	 public void startUp(){
		 System.out.println("Startup method executed");
	 }
	 
	 @PreDestroy
	 public void destroy(){
		 System.out.println("Destroy method executed");
	 }
}

