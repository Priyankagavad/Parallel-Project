package com.cg1;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

public class Main2 {

	public static void main(String[] args) {
		
		// Java Configuration using MyConfig.class file
		AbstractApplicationContext context = new AnnotationConfigApplicationContext(MyConfig.class);
		
		Customer cust = (Customer) context.getBean("customer");
		Customer cust1 = (Customer) context.getBean("cust");
		
		System.out.println(cust);
		System.out.println(cust1);
		
		Circle1 c = (Circle1) context.getBean("circle1");
		c.draw();
		System.out.println("Done successfully");
	}
}
