package com.cg;

import java.util.List;

public class Triangle{

	/* private String type;
	 private int height;
	
	 public Triangle() {
	 super();
	 // TODO Auto-generated constructor stub
	 }
	
	 public Triangle(String type) {
	 super();
	 this.type = type;
	 }
	
	 public Triangle(int height) {
	 super();
	 this.height = height;
	 }
	
	public int getHeight() {
	 return height;
	 }
	
	 public void setHeight(int height) {
	 this.height = height;
	}
	
	 public void setType(String type) {
	 this.type = type;
	 }
	
	 public String getType() {
	 return type;
	 }
	
	 public void draw(){
	 System.out.println(type+ " Traingle is drawn with height " +height);
	 }*/
	 
	 
	private Point pointA;
	private Point pointB;
	private Point pointC;

	public Point getPointA() {
		return pointA;
	}

	public void setPointA(Point pointA) {
		this.pointA = pointA;
	}

	public Point getPointB() {
		return pointB;
	}

	public void setPointB(Point pointB) {
		this.pointB = pointB;
	}

	public Point getPointC() {
		return pointC;
	}

	public void setPointC(Point pointC) {
		this.pointC = pointC;
	}

	public void draw() {
		System.out.println("Point A (" + pointA.getX() + ", " + pointA.getY() + ")");
		System.out.println("Point B (" + pointB.getX() + ", " + pointB.getY() + ")");
		System.out.println("Point C (" + pointC.getX() + ", " + pointC.getY() + ")");
	}
	
	/*@Override
	public void afterPropertiesSet() throws Exception{
		System.out.println("After properties set of Initializing bean");
	}*/
	
	/*public void myInit(){
		System.out.println("My Init method executed");
	}
	
	public void tearDown(){
		System.out.println("My Destroy method executed");
	}*/
	
	
	
	/*private List<Point> points;

	public List<Point> getPoints() {
		return points;
	}

	public void setPoints(List<Point> points) {
		this.points = points;
	}
	
	public void draw(){
		for(Point point:points){
			System.out.println("Point("+point.getX()+"," +point.getY()+")");
		}
	}*/

}
