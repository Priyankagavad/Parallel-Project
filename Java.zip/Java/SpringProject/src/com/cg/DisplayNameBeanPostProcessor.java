package com.cg;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

public class DisplayNameBeanPostProcessor implements BeanPostProcessor {

	@Override
	public Object postProcessAfterInitialization(Object arg0, String arg1) throws BeansException {
		//System.out.println("Post process after initialization " +arg1);
		
		if(arg1.equals("point2")){
			((Point)arg0).setX(200);
			((Point)arg0).setY(100);
		}
		return arg0;
	}

	@Override
	public Object postProcessBeforeInitialization(Object arg0, String arg1) throws BeansException {
		//System.out.println("Post process before initialization " +arg1);
		return arg0;
	}

}
