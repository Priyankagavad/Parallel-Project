package com.app.util;

import java.util.Scanner;

public class Main {

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the access code:");
		int accessCode = sc.nextInt();
		String s = validateAccessCode(accessCode);
		System.out.println(s);
		sc.close();
	}

	public static String validateAccessCode(int accessCode) {
		
		String str = String.valueOf(accessCode);
		int sum = 0;
		if (str.length() == 4) {
			
			for (int i = 1; i <= str.length(); i++) {
				if (i % 2 == 0) {
					char c = str.charAt(i);
					int n = Integer.parseInt(String.valueOf(c));
					System.out.println(n);
					sum = sum + n; 
				}
			}
			System.out.println(sum);
			if (sum % 2 == 0) {
				return "Valid access code";
			} else {
				return "Invalid access code";
			}
		} else {
			return "Invalid Input";
		}
	}
}