package com.ui;

import java.util.Scanner;

import com.bean.Student;
import com.utility.College;

public class UserInterface {
	
	public static void main(String a[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of student details");
		int stno = sc.nextInt();
		String[] stlist = new String[stno];
		System.out.println("Enter the student details");
		for(int i=0;i<stno;i++){
			
			stlist[i] = sc.next();
		}
		System.out.println("Enter the grade");
		String grade = sc.next();
		
		
		College clg = new College();
		for(int i=0;i<stno;i++) {
			Student st = new Student();
			st.parseData(stlist[i]);
			clg.addStudent(st);
		}
		System.out.println("Count:"+clg.countBasedOnGrade(grade));
	}
	
	
}
