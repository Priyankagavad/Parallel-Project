package com.ui;

import java.util.Scanner;

import com.utility.Shop;

public class UserInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		// Fill the UI code
		
		System.out.println("Enter the no of Face Creams you want to store:");
		int size = sc.nextInt();
		int serialNumber;
		String productName;
		Shop shop = new Shop(size);
		for (int i = 1; i <= size; i++) {
			System.out.println("Enter the key" + i);
			serialNumber = sc.nextInt();
			System.out.println("Enter the value" + i);
			productName = sc.next();
			shop.addProductDetails(serialNumber, productName);
		}
		System.out.println("Enter the product type to be searched");
		String productType = sc.next();
		shop.searchBasedOnproduct(productType);

	}

}
