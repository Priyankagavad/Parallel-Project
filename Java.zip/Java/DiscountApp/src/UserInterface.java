
import java.util.Arrays;
import java.util.Scanner;

public class UserInterface {

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int noOfProducts = sc.nextInt();
		int price, disPer;
		float calDis;
		float[] dis = new float[noOfProducts];
		String products[] = new String[noOfProducts];
		for (int i = 0; i < noOfProducts; i++) {
			products[i] = sc.next();
			price = sc.radix();
			disPer = sc.radix();
			calDis = (disPer / 100) * price;
			dis[i] = calDis;
		}
		Arrays.sort(dis);
		System.out.println(+dis[0]);

	}

}
