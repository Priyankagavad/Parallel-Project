package com.app.util;

import java.util.Scanner;

public class Main {

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		String s = sc.next();
		String password = generate(s);
		System.out.println(password);
		sc.close();
	}

	public static String generate(String s) {
		if (s.length() < 5) {
			return "Invalid Input";
		} else {
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < s.length(); i = i + 2) {
				sb.append(s.charAt(i));
			}
			return sb.toString().toUpperCase();
		}
	}
}
