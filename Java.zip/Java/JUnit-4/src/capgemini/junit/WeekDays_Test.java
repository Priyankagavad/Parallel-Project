package capgemini.junit;

public class WeekDays_Test {

	String[] weekDays = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
}
