package capgemini.junit;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class Junit_LifeCycle_Test {

	@BeforeClass
	public static void beforeClass() {
		System.out.println("Lifecycle->beforeclass");
	}

	@Before
	public void before() {
		System.out.println("\tLifecycle->before");
	}

	@Test
	public void testOne() {
		System.out.println("\t\tLifecycle->testOne");
	}

	@Test
	public void testTwo() {
		System.out.println("\t\tLifecycle->testTwo");
	}

	@After
	public void after() {
		System.out.println("\tLifecycle->after");
	}

	@AfterClass
	public static void afterClass() {
		System.out.println("Lifecycle->afterclass");
	}
}
