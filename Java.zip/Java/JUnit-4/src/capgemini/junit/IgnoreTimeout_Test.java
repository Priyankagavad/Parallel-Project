package capgemini.junit;

import static org.junit.Assert.fail;

import org.junit.Ignore;
import org.junit.Test;

public class IgnoreTimeout_Test {

	@Ignore("Yet to implement.....")
	@Test
	public void testIgnore() {
		System.out.println("testIgnore");
		fail("@Ignore method will not run by JUnit 4");
	}

	@Test(timeout = 500)
	public void testTimeOut() {
		System.out.println("@Test(timeout) can be used to enforce timeout in JUnit");
		while (true) {

		}
	}
}
