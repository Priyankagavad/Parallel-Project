package capgemini.junit;

import org.junit.Ignore;
import org.junit.Test;

public class Demo {

	@Ignore @Test(expected=ClassCastException.class)
	public void testGetLastName(){}
	
	@Ignore @Test(expected=ClassCastException.class)
	public void testGetFirstName(){}
}
