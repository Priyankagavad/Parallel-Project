package com.cg.entity.association;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		
		Faculty fac = new Faculty();
		fac.setName("Rushi");
		
		Technology tech = new Technology();
		tech.setTechName("Java");
		
		Technology tech2 = new Technology();
		tech2.setTechName("BDD");
		
		fac.getTechnologies().add(tech);
		fac.getTechnologies().add(tech2);
		
		tech.getFaculties().add(fac);
		tech2.getFaculties().add(fac);
//		tech.setFac(fac);
//		tech2.setFac(fac);
		
		//fac.setTechnology(tech);
		//tech.setFac(fac);
		
		em.getTransaction().begin();
		
		em.persist(fac);
		em.persist(tech);
		em.persist(tech2);
		em.getTransaction().commit();
	}
}
