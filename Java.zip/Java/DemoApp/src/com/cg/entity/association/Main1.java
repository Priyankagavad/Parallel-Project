package com.cg.entity.association;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main1 {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		
		Faculty fac = em.find(Faculty.class, 1);
		System.out.println(fac);
		//em.close();
		for(Technology tech:fac.getTechnologies()){
			System.out.println(tech);
		}
	}
}
