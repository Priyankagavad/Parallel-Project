package com.cg.entity.association;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class Technology {

	@Id
	@GeneratedValue
	private int techId;
	private String techName;
	
	@ManyToMany
	private List<Faculty> faculties = new ArrayList<>();
	
//	@ManyToOne
//	private Faculty fac;
	
	//@OneToOne(mappedBy = "technology")
	//private Faculty fac;
	
//	public Faculty getFac() {
//		return fac;
//	}
//	public void setFac(Faculty fac) {
//		this.fac = fac;
//	}
	
	
	
//	public Faculty getFac() {
//		return fac;
//	}
//	public void setFac(Faculty fac) {
//		this.fac = fac;
//	}
	
	
	public int getTechId() {
		return techId;
	}
	public List<Faculty> getFaculties() {
		return faculties;
	}
	public void setFaculties(List<Faculty> faculties) {
		this.faculties = faculties;
	}
	public void setTechId(int techId) {
		this.techId = techId;
	}
	public String getTechName() {
		return techName;
	}
	public void setTechName(String techName) {
		this.techName = techName;
	}
	@Override
	public String toString() {
		return String.format("Technology [techId=%s, techName=%s]", techId, techName);
	}
	
}
