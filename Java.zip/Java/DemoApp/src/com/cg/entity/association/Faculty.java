package com.cg.entity.association;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Faculty {
	@Id
	@GeneratedValue
	private int id;
	private String name;
	
	//@OneToMany(cascade = CascadeType.PERSIST, mappedBy="fac")
	
	//@JoinTable(name="factech", joinColumns=@JoinColumn(name="facId"), inverseJoinColumns = @JoinColumn(name = "techId"))
	@ManyToMany(cascade = CascadeType.PERSIST, mappedBy="faculties")
	private List<Technology> technologies = new ArrayList<>();
	
//	@OneToOne(cascade = CascadeType.ALL)
//	@JoinColumn(name="techId")
//	private Technology technology;

//	public Technology getTechnology() {
//		return technology;
//	}
//
//	public void setTechnology(Technology technology) {
//		this.technology = technology;
//	}

	
	
	public List<Technology> getTechnologies() {
		return technologies;
	}

	public void setTechnologies(List<Technology> technologies) {
		this.technologies = technologies;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return String.format("Faculty [id=%s, name=%s]", id, name);
	}

	

}
