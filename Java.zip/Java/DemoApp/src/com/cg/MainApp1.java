package com.cg;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class MainApp1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		
		System.out.println("Enter gender");
		String gender = sc.nextLine();
		TypedQuery<Employee> query = em.createQuery("from Employee where gender=:gen", Employee.class);
		query.setParameter("gen", gender);
		List<Employee> employees = query.getResultList();
		for(Employee employee: employees){
			System.out.println(employee);
		}
}
}
