package com.cg;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class MainApp {
	public static void main(String[] args){
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		/*Employee emp = new Employee(103, 22, "Dheeraj", "Male", 100000000);
		em.getTransaction().begin();
		em.persist(emp);
		em.getTransaction().commit();
		System.out.println("Data Saved");
		*/
//		em.getTransaction().begin();		
//		Employee emp=em.find(Employee.class, 103);
//		System.out.println(emp);
//		em.remove(emp);
//		Employee e=em.find(Employee.class, 103);
//		em.detach(e);
//		e.setAge(24);
//		em.merge(e);
//		em.getTransaction().commit();
//		System.out.println(e);
		
		
		Employee emp = new Employee();
		emp.setAge(22);
		emp.setGender("Female");
		emp.setName("Shijuka");
		emp.setSalary(50000);
		em.getTransaction().begin();
		em.persist(emp);
		em.getTransaction().commit();
		System.out.println("After Commit");
	}
}
