package com.cg;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class MainApp3 {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		Scanner sc = new Scanner(System.in);
		
		TypedQuery<Employee> query = em.createNamedQuery("getAllEmployees", Employee.class);
		List<Employee> employees = query.getResultList();
		for(Employee employee: employees){
			System.out.println(employee);
		}
		
		query = em.createNamedQuery("getEmployeesByGender", Employee.class);
		query.setParameter("gen", "Male");
		List<Employee> employees1 = query.getResultList();
		for(Employee employee: employees1){
			System.out.println(employee);
		}
	}
}
