package com.cg;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class MainApp2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
//		System.out.println("Enter employee ID");
//		int empId = sc.nextInt();
		
//		Query query = em.createQuery("delete from Employee where id=:eno");
//		query.setParameter("eno", empId);
//		em.getTransaction().begin();
//		int result = query.executeUpdate();
//		em.getTransaction().commit();
//		System.out.println(result+ "rows deleted");
		
//		Update
//		System.out.println("Enter employee gender");
//		String gender = sc.next();
//		System.out.println("Enter salary");
//		double sal = sc.nextDouble();
//		System.out.println("Enter age");
//		int age = sc.nextInt();
//		Query query = em.createQuery("update Employee set salary=salary+?, age=age+? where gender=?");
//		query.setParameter(1, sal);
//		query.setParameter(2, age);
//		query.setParameter(3, gender);
//		em.getTransaction().begin();
//		int result = query.executeUpdate();
//		em.getTransaction().commit();
//		System.out.println(result+ "rows updated");

		// Update
				System.out.println("Enter employee gender");
				String gender = sc.next();
				System.out.println("Enter salary");
				double sal = sc.nextDouble();
				System.out.println("Enter age");
				int age = sc.nextInt();
				Query query = em.createQuery("update Employee set salary=salary+:s, age=age+:a where gender=:g");
				query.setParameter("s", sal);
				query.setParameter("a", age);
				query.setParameter("g", gender);
				em.getTransaction().begin();
				int result = query.executeUpdate();
				em.getTransaction().commit();
				System.out.println(result+ "rows updated");
				
		
		
	}
}
