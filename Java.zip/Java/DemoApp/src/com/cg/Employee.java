package com.cg;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="employee_details")
@NamedQueries({@NamedQuery(name = "getAllEmployees", query = "from Employee"),
	@NamedQuery(name = "getEmployeesByGender", query = "from Employee where gender=:gen")})
public class Employee {
	
	
	@Id
	//@SequenceGenerator(name = "myseq", sequenceName="emp_seq", initialValue=1001, allocationSize=1)
	//@GeneratedValue(generator = "myseq", strategy=GenerationType.SEQUENCE)
	@Column(name="empId")
	private int id;
	
	private int age;
	
	@Column(name="empName")
	private String name;
	
	@Column(name="empGender")
	private String gender;
	
	@Column(name="annualSalary")
	private double salary;
	
	public Employee() {
		
	}
	public Employee(int id, int age, String name, String gender, double salary) {
		super();
		this.id = id;
		this.age = age;
		this.name = name;
		this.gender = gender;
		this.salary = salary;
	}
	@Override
	public String toString() {
		return String.format("Employee [id=%s, age=%s, name=%s, gender=%s, salary=%s]", id, age, name, gender, salary);
	}
	
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public int getId() {
		return id;
	}
	
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
}
