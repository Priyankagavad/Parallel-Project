package Lab1;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		Scanner sc = new Scanner(System.in);

		// Data Insertion
		System.out.println("Enter author id: ");
		int id = sc.nextInt();

		System.out.println("Enter first name: ");
		String firstName = sc.next();

		System.out.println("Enter first name: ");
		String middleName = sc.next();

		System.out.println("Enter first name: ");
		String lastName = sc.next();

		System.out.println("Enter phone number: ");
		long phoneNo = sc.nextLong();

		Author author = new Author(id, firstName, middleName, lastName, phoneNo);
		em.getTransaction().begin();
		em.persist(author);
		em.getTransaction().commit();
		System.out.println("Data Inserted");

		// Data Finding
		System.out.println("******************************");
		Author author1;
		em.getTransaction().begin();
		System.out.println("Enter author id to find author: ");
		author1 = em.find(Author.class, sc.nextInt());
		em.persist(author1);
		em.getTransaction().commit();
		System.out.println(author1);
		System.out.println("Data Find...");

		// Data Update
		System.out.println("******************************");
		Author author2;
		em.getTransaction().begin();
		System.out.println("Enter author id to update author info: ");
		author2 = em.find(Author.class, sc.nextInt());
		em.detach(author2);
		System.out.println("Enter phone no: ");
		author2.setPhoneNo(sc.nextLong());
		em.merge(author2);
		em.getTransaction().commit();
		System.out.println(author2);
		System.out.println("Data updated");

		// Data delete
		System.out.println("******************************");
		Author author3;
		em.getTransaction().begin();
		System.out.println("Enter author id to delete author: ");
		author3 = em.find(Author.class, sc.nextInt());
		em.persist(author3);
		em.remove(author3);
		em.getTransaction().commit();
		System.out.println("Data removed");

	}
}
