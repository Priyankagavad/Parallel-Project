package Lab2_2;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Author2 {
	
	
	@GeneratedValue
	private int id;
	
	@Id
	private String name;
	
	@OneToMany(cascade = CascadeType.ALL)
	private List<Book1> books=new ArrayList<>();
	
	public List<Book1> getBooks() {
		return books;
	}
	public void setBooks(List<Book1> books) {
		this.books = books;
	}
	public int getId() {
		return id;
	}
	/*public void setId(int id) {
		this.id = id;
	}*/
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return String.format("Author [id=%s, name=%s]", id, name);
	}
	
	
}
