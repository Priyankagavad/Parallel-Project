package Lab2_2;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;




public class Main {

	public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		Scanner sc = new Scanner(System.in);
		
		/*Author2 auth = new Author2();
		System.out.println("Enter author name: ");
		String authorName = sc.next();
		auth.setName(authorName);
		
		// adding books in database
		Book1 book = new Book1();
		
		System.out.println("Enter book title: ");
		String bookTitle = sc.next();
		book.setTitle(bookTitle);
		System.out.println("Enter book price: ");
		int bookPrice = sc.nextInt();
		book.setPrice(bookPrice);
		
		auth.getBooks().add(book);
		book.setAuth(auth);
		
		em.getTransaction().begin();
		em.persist(book);
		em.persist(auth);
		em.getTransaction().commit();*/
		
		System.out.println("Enter Author Name");
		String Name = sc.nextLine();
		TypedQuery<Author2> query = em.createQuery("from Author2 where Name=:n", Author2.class);
		query.setParameter("n", Name);
		List<Author2> author= query.getResultList();
		for(Author2 auth1:author){
			System.out.println(auth1.getBooks());
		}
	}
}
