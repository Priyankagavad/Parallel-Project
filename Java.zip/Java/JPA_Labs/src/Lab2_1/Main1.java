package Lab2_1;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;



public class Main1 {

	public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		
		Author1 auth = new Author1();
		auth.setName("Leonard");
		
		Book book = new Book();
		book.setTitle("A Briefer History of Time");
		book.setPrice(500);
		
		auth.getBooks().add(book);
		
		em.getTransaction().begin();
		em.persist(book);
		em.persist(auth);
		em.getTransaction().commit();
		
		for(Book books:auth.getBooks() ){
			System.out.println(books);
		}
	}
}
