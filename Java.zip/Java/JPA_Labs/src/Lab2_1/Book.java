package Lab2_1;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;



@Entity
public class Book {

	@Id
	@GeneratedValue
	private int ISBN;
	private String title;
	private int price;
	
	@ManyToOne
	private Author1 auth;
	
	public Author1 getAuth() {
		return auth;
	}
	public void setAuth(Author1 auth) {
		this.auth = auth;
	}
	public int getISBN() {
		return ISBN;
	}
	public void setISBN(int iSBN) {
		ISBN = iSBN;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return String.format("Book [ISBN=%s, title=%s, price=%s]", ISBN, title, price);
	}
	
}
