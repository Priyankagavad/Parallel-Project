package com.app.util;

import java.util.Scanner;

public class Main {

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int n1 = sc.nextInt();
		int n2 = sc.nextInt();
		int num = count(n1, n2);
		System.out.println(num);
		sc.close();
	}

	public static int count(int n1, int n2) {
		int count = 0, rem = 0;
		while (n1 != 0) {
			rem = n1 % 10;
			if (rem == n2) {
				count++;
			}
			n1 = n1 / 10;
		}
		return count;
	}
}
