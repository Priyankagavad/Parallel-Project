package com.capgemini.banking.exception;

public class NotSufficientBalanceException extends Exception {

	public NotSufficientBalanceException(String message) {
		super(message);
	}
}
