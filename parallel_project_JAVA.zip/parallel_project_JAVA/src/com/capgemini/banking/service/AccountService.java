package com.capgemini.banking.service;

import java.util.Collection;

import com.capgemini.banking.bean.Account;
import com.capgemini.banking.exception.AccountNotFoundException;
import com.capgemini.banking.exception.NotSufficientBalanceException;

public interface AccountService {

	public Account creatAccount(Account account);

	public double showBalance(int accountNo) throws AccountNotFoundException;

	public void deposit(int accountNo, int amount) throws AccountNotFoundException;

	public void withdraw(int accountNo, int amount) throws AccountNotFoundException, NotSufficientBalanceException;

	public void fundTransfer(int accountNoFrom, int accountNoTo, int amount)
			throws AccountNotFoundException, NotSufficientBalanceException;

	public Collection<Account> printTransactions(int accountNo);
}
