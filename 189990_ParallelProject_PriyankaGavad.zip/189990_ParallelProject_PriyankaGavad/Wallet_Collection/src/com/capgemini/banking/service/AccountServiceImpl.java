package com.capgemini.banking.service;

import java.util.Collection;
import java.util.HashMap;

import com.capgemini.banking.bean.Account;
import com.capgemini.banking.dao.AccountDao;
import com.capgemini.banking.dao.AccountDaoImpl;
import com.capgemini.banking.exception.AccountNotFoundException;
import com.capgemini.banking.exception.NotSufficientBalanceException;

public class AccountServiceImpl implements AccountService {
	AccountDao accountDAO;

	public AccountServiceImpl(int size) {
		accountDAO = new AccountDaoImpl(size);
	}

	@Override
	public int createAccount(Account account) {
		return accountDAO.createAccount(account);
	}

	@Override
	public void deposit(int accountNo, double amount) throws AccountNotFoundException {
		accountDAO.deposit(accountNo, amount);
	}

	@Override
	public void withdraw(int accountNo, double amount) throws AccountNotFoundException, NotSufficientBalanceException {
		accountDAO.withdraw(accountNo, amount);
	}

	@Override
	public void fundsTransfer(int accountNoFrom, int accountNoTo, double amount)
			throws AccountNotFoundException, NotSufficientBalanceException {
		accountDAO.fundsTransfer(accountNoFrom, accountNoTo, amount);
	}

	@Override
	public double getBalance(int accountNo) throws AccountNotFoundException {
		return accountDAO.getBalance(accountNo);
	}

	@Override
	public Collection<Account> getTransactions() {
		return accountDAO.getTransactions();
	}
}
