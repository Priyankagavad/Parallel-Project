package com.capgemini.banking.service;

import java.sql.SQLException;

import com.capgemini.banking.bean.Account;
import com.capgemini.banking.dao.AccountDao;
import com.capgemini.banking.dao.AccountDaoImpl;
import com.capgemini.banking.exception.AccountNotFoundException;
import com.capgemini.banking.exception.NotSufficientBalanceException;

public class AccountServiceImpl implements AccountService {

	Account account;

	private AccountDao getAccountDao() {
		return new AccountDaoImpl();
	}

	@Override
	public int creatAccount(Account account) throws ClassNotFoundException, SQLException {
		AccountDao accountDao = getAccountDao();
		return accountDao.creatAccount(account);
	}

	@Override
	public double deposit(int accountNo, int amount)
			throws AccountNotFoundException, ClassNotFoundException, NotSufficientBalanceException, SQLException {
		AccountDao accountDao = getAccountDao();
		return accountDao.deposit(accountNo, amount);
	}

	@Override
	public double showBalance(int accountNo) throws AccountNotFoundException, ClassNotFoundException, SQLException {
		AccountDao accountDao = getAccountDao();
		return accountDao.showBalance(accountNo);
	}

	@Override
	public double withdraw(int accountNo, int amount)
			throws AccountNotFoundException, NotSufficientBalanceException, ClassNotFoundException, SQLException {
		AccountDao accountDao = getAccountDao();
		return accountDao.withdraw(accountNo, amount);
	}

	/*
	 * @Override public Collection<Account> printTransactions(int accountNo) {
	 * return hashmap.values(); }
	 */

	@Override
	public double fundTransfer(int accountNoFrom, int accountNoTo, int amount)
			throws AccountNotFoundException, NotSufficientBalanceException, ClassNotFoundException, SQLException {
		AccountDao accountDao = getAccountDao();
		return accountDao.fundTransfer(accountNoFrom, accountNoTo, amount);
	}
}
