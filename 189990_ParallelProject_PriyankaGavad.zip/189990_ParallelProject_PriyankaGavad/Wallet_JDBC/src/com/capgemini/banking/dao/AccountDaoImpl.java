package com.capgemini.banking.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.banking.bean.Account;
import com.capgemini.banking.exception.AccountNotFoundException;
import com.capgemini.banking.exception.NotSufficientBalanceException;

public class AccountDaoImpl implements AccountDao {

	Account account;

	@Override
	public int creatAccount(Account account) throws ClassNotFoundException, SQLException {
		int count = 0;
		int accountNum = account.getAccountNo();
		Connection conn = AccountDB.getConnection();
		Statement stmt = conn.createStatement();
		String query = "select count(*) from bank_wallet_account where accountNo=\'" + accountNum + "\'";
		ResultSet rs = stmt.executeQuery(query);
		if (rs.next() && rs.getInt(1) == 0) {
			String insertQuery = "INSERT INTO bank_wallet_account values(?,?,?,?)";
			PreparedStatement pStmt = conn.prepareStatement(insertQuery);
			pStmt.setInt(1, account.getAccountNo());
			pStmt.setString(2, account.getAccountName());
			pStmt.setDouble(3, account.getOpeningBalance());
			pStmt.setDouble(4, account.getCurrentBalance());
			count = pStmt.executeUpdate();

		}
		conn.close();
		if (count > 0)
			return accountNum;
		return (Integer) null;

	}

	@Override
	public double deposit(int accountNo, int amount)
			throws AccountNotFoundException, SQLException, ClassNotFoundException, NotSufficientBalanceException {
		if (amount <= 0) {
			throw new NotSufficientBalanceException("Entered Amount is invalid ");
		}

		Connection conn = AccountDB.getConnection();
		Statement stmt = conn.createStatement();

		Account account = getAccount(accountNo);
		double newBalance = account.getCurrentBalance() + amount;
		String query = "update bank_wallet_account set currentbalance=" + newBalance + " where accountNo=\'" + accountNo
				+ "\'";
		stmt.executeUpdate(query);
		conn.close();
		return newBalance;

	}

	@Override
	public double showBalance(int accountNo) throws AccountNotFoundException, ClassNotFoundException, SQLException {
		Account account = getAccount(accountNo);
		System.out.println(
				"Current balance in account number " + accountNo + " is Rs. " + account.getCurrentBalance() + " .");
		return account.getCurrentBalance();

	}

	@Override
	public double withdraw(int accountNo, int amount)
			throws AccountNotFoundException, NotSufficientBalanceException, ClassNotFoundException, SQLException {
		if (amount <= 0) {
			throw new NotSufficientBalanceException("Entered Amount is invalid " + amount);
		}
		Connection conn = AccountDB.getConnection();
		Statement stmt = conn.createStatement();

		Account account = getAccount(accountNo);
		if (amount > account.getCurrentBalance()) {
			throw new NotSufficientBalanceException("You have Insufficient funds in your account.");
		}
		double newBalance = account.getCurrentBalance() - amount;
		String query = "update bank_wallet_account set currentbalance=" + newBalance + " where accountNo=\'" + accountNo
				+ "\'";
		stmt.executeUpdate(query);
		conn.close();
		return newBalance;

	}

	@Override
	public double fundTransfer(int accountNoFrom, int accountNoTo, int amount)
			throws AccountNotFoundException, NotSufficientBalanceException, ClassNotFoundException, SQLException {

		if (amount <= 0) {
			throw new NotSufficientBalanceException("Entered Amount is invalid " + amount);
		}

		Account account = getAccount(accountNoFrom);
		Account account_rec = getAccount(accountNoTo);
		if (amount > account.getCurrentBalance()) {
			throw new NotSufficientBalanceException("You have Insufficient funds in your account.");
		}

		Connection conn = AccountDB.getConnection();
		Statement stmt = conn.createStatement();
		account_rec.setCurrentBalance(account_rec.getCurrentBalance() + amount);
		account.setCurrentBalance(account.getCurrentBalance() - amount);
		String query = "update bank_wallet_account set currentbalance=" + account.getCurrentBalance()
				+ " where accountNo=\'" + accountNoFrom + "\'";
		stmt.executeUpdate(query);
		String query2 = "update bank_wallet_account set currentbalance=" + account_rec.getCurrentBalance()
				+ " where accountNo=\'" + accountNoTo + "\'";
		stmt.executeUpdate(query2);
		conn.close();
		return account.getCurrentBalance();

	}

	/*
	 * @Override public Collection<Account> printTransactions(int accountNo) {
	 * return hashmap.values(); }
	 */

	@Override
	public Account getAccount(int accountNo) throws AccountNotFoundException, ClassNotFoundException, SQLException {
		Account account = new Account();
		Connection conn = AccountDB.getConnection();
		Statement stmt = conn.createStatement();
		String query = "select * from bank_wallet_account where accountNo=\'" + accountNo + "\'";
		ResultSet rs = stmt.executeQuery(query);
		if (rs.next()) {
			account.setAccountNo(rs.getInt(1));
			account.setAccountName(rs.getString(2));
			account.setOpeningBalance(rs.getDouble(3));
			account.setCurrentBalance(rs.getDouble(4));

			conn.close();
			return account;
		}
		throw new AccountNotFoundException("No account found for account number " + accountNo);

	}
}
