package com.capgemini.banking.dao;

import java.sql.SQLException;
import java.util.Collection;

import com.capgemini.banking.bean.Account;
import com.capgemini.banking.exception.AccountNotFoundException;
import com.capgemini.banking.exception.NotSufficientBalanceException;

public interface AccountDao {
	public int createAccount(Account account) throws ClassNotFoundException, SQLException;

	public void beginTransaction();

	public void commitTransaction();

	public double deposit(int accountNo, int amount) throws AccountNotFoundException, NotSufficientBalanceException;

	public Account getAccount(int accountNo) throws AccountNotFoundException;

	public double showBalance(int accountNo) throws AccountNotFoundException;

	public double withdraw(int accountNo, int amount) throws AccountNotFoundException, NotSufficientBalanceException;

	public double fundTransfer(int accountNoFrom, int accountNoTo, int amount)
			throws NotSufficientBalanceException, AccountNotFoundException;

}
