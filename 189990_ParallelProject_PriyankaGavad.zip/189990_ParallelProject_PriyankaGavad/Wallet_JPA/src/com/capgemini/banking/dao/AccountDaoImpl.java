package com.capgemini.banking.dao;

import javax.persistence.EntityManager;

import com.capgemini.banking.bean.Account;
import com.capgemini.banking.exception.AccountNotFoundException;
import com.capgemini.banking.exception.NotSufficientBalanceException;

public class AccountDaoImpl implements AccountDao {
	private EntityManager entityManager;
	Account account;

	public AccountDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}

	/*
	 * begins the transaction
	 */
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

	/*
	 * commits the transaction
	 */
	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}

	@Override
	public int createAccount(Account account) {
		entityManager.persist(account);
		return account.getAccountNo();
	}

	@Override
	public double deposit(int accountNo, int amount) throws NotSufficientBalanceException, AccountNotFoundException {
		Account account = getAccount(accountNo);
		if (amount <= 0) {
			throw new NotSufficientBalanceException("Entered Amount is invalid ");
		}
		double newBalance = account.getCurrentBalance() + amount;
		account.setCurrentBalance(newBalance);
		entityManager.merge(account);
		return newBalance;
	}

	@Override
	public double showBalance(int accountNo) throws AccountNotFoundException {
		Account account = getAccount(accountNo);
		System.out.println(
				"Current balance in account number " + accountNo + " is Rs. " + account.getCurrentBalance() + " .");
		return account.getCurrentBalance();
	}

	@Override
	public double withdraw(int accountNo, int amount) throws NotSufficientBalanceException, AccountNotFoundException {
		Account account = getAccount(accountNo);
		if (amount <= 0) {
			throw new NotSufficientBalanceException("Entered Amount is invalid " + amount);
		}

		if (amount > account.getCurrentBalance()) {
			throw new NotSufficientBalanceException("You have Insufficient funds in your account.");
		}
		double newBalance = account.getCurrentBalance() - amount;
		account.setCurrentBalance(newBalance);
		entityManager.merge(account);
		return newBalance;
	}

	@Override
	public double fundTransfer(int accountNoFrom, int accountNoTo, int amount)
			throws NotSufficientBalanceException, AccountNotFoundException {
		if (amount <= 0) {
			throw new NotSufficientBalanceException("Entered Amount is invalid " + amount);
		}
		Account account = getAccount(accountNoFrom);
		Account account_rec = getAccount(accountNoTo);
		if (amount > account.getCurrentBalance()) {
			throw new NotSufficientBalanceException("You have Insufficient funds in your account.");
		}
		account_rec.setCurrentBalance(account_rec.getCurrentBalance() + amount);
		account.setCurrentBalance(account.getCurrentBalance() - amount);
		entityManager.merge(account);
		entityManager.merge(account_rec);
		return account.getCurrentBalance();

	}

	@Override
	public Account getAccount(int accountNo) throws AccountNotFoundException {
		Account account = null;
		account = entityManager.find(Account.class, accountNo);
		if (account == null) {
			throw new AccountNotFoundException("No account found for account number " + accountNo);
		}
		return account;
	}
}
