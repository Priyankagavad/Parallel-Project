package com.capgemini.banking.service;

import java.sql.SQLException;
import java.util.Collection;

import com.capgemini.banking.bean.Account;
import com.capgemini.banking.exception.AccountNotFoundException;
import com.capgemini.banking.exception.NotSufficientBalanceException;

public interface AccountService {

	public int createAccount(Account account) throws ClassNotFoundException, SQLException;

	public double deposit(int accountNo, int amount) throws AccountNotFoundException, NotSufficientBalanceException;

	public double showBalance(int accountNo) throws AccountNotFoundException, ClassNotFoundException, SQLException;

	public double withdraw(int accountNo, int amount)
			throws AccountNotFoundException, NotSufficientBalanceException, ClassNotFoundException, SQLException;

	public double fundTransfer(int accountNoFrom, int accountNoTo, int amount)
			throws ClassNotFoundException, AccountNotFoundException, NotSufficientBalanceException, SQLException;

}
