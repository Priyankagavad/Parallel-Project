package com.capgemini.banking.service;

import java.sql.SQLException;

import com.capgemini.banking.bean.Account;
import com.capgemini.banking.dao.AccountDao;
import com.capgemini.banking.dao.AccountDaoImpl;
import com.capgemini.banking.exception.AccountNotFoundException;
import com.capgemini.banking.exception.NotSufficientBalanceException;

public class AccountServiceImpl implements AccountService {

	private AccountDao AccountDao = new AccountDaoImpl();

	@Override
	public int createAccount(Account account) throws ClassNotFoundException, SQLException {
		int accountNo = account.getAccountNo();

		account.setAccountNo(accountNo);
		account.setAccountName(account.getAccountName());

		account.setCurrentBalance(account.getCurrentBalance());
		account.setOpeningBalance(account.getOpeningBalance());
		AccountDao.beginTransaction();
		AccountDao.createAccount(account);
		AccountDao.commitTransaction();
		return accountNo;
	}

	@Override
	public double deposit(int accountNo, int amount) throws AccountNotFoundException, NotSufficientBalanceException {
		AccountDao.beginTransaction();
		double balance = AccountDao.deposit(accountNo, amount);
		AccountDao.commitTransaction();
		return balance;
	}

	@Override
	public double showBalance(int accountNo) throws ClassNotFoundException, AccountNotFoundException, SQLException {
		return AccountDao.showBalance(accountNo);
	}

	@Override
	public double withdraw(int accountNo, int amount)
			throws ClassNotFoundException, AccountNotFoundException, NotSufficientBalanceException, SQLException {
		AccountDao.beginTransaction();
		double balance = AccountDao.withdraw(accountNo, amount);
		AccountDao.commitTransaction();
		return balance;
	}

	@Override
	public double fundTransfer(int accountNoFrom, int accountNoTo, int amount)
			throws ClassNotFoundException, AccountNotFoundException, NotSufficientBalanceException, SQLException {
		AccountDao.beginTransaction();
		double balance = AccountDao.fundTransfer(accountNoFrom, accountNoTo, amount);
		AccountDao.commitTransaction();
		return balance;
	}
}
