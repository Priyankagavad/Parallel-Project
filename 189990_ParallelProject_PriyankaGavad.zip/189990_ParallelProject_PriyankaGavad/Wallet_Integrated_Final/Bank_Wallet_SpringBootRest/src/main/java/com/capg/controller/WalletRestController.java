package com.capg.controller;

import java.util.HashMap;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg.wallet.beans.Account;
import com.capg.wallet.beans.Transaction;
import com.capg.wallet.services.WalletService;
import com.capg.wallet.utils.BankWalletException;
import com.capg.wallet.utils.SampleResponse;
import com.capg.wallet.utils.WalletRequestModel;

/*
 * Controller for all the requests which come to the spring application
 */
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:4200")
public class WalletRestController {

	@Autowired
	private WalletService walletService;

	/*
	 * Creates new account
	 * 
	 * @Param Account object from request body
	 * 
	 * @Return Account Number in ResponseEntity of String
	 */
	@PostMapping(value = "/create")
	public ResponseEntity<SampleResponse> creatAccount(@Valid @RequestBody Account account) throws BankWalletException {
		String accountNum = walletService.createAccount(account.getName(), account.getMobile(), account.getDob(),
				account.getPassword());
		HashMap<String, Object> data = new HashMap<String, Object>();
		data.put("account_number", accountNum);
		SampleResponse sampleRespose = new SampleResponse(true, data);
		ResponseEntity<SampleResponse> response = new ResponseEntity<SampleResponse>(sampleRespose, HttpStatus.CREATED);
		return response;
	}

	/*
	 * Returns the balance in the account
	 * 
	 * @Return Balance in ResponseEntity of Double
	 * 
	 * @Param Account number as String and password as String from request body
	 */
	@PostMapping(value = "/balance")
	public ResponseEntity<SampleResponse> getBalance(@Valid @RequestBody WalletRequestModel requestModel)
			throws BankWalletException {
		Double balance = walletService.getBalance(requestModel.getAccountNumber(), requestModel.getPassword());
		HashMap<String, Object> data = new HashMap<String, Object>();
		data.put("account_number", requestModel.getAccountNumber());
		data.put("balance", balance);
		SampleResponse sampleRespose = new SampleResponse(true, data);
		ResponseEntity<SampleResponse> response = new ResponseEntity<SampleResponse>(sampleRespose,
				HttpStatus.ACCEPTED);
		return response;
	}
	/*
	 * returns the list of transactions for given account number
	 * 
	 * @Return Response<List<Transaction>>
	 * 
	 * @Param Account number as String and password as String from request body
	 */

	@PostMapping(value = "/transactions")
	public ResponseEntity<SampleResponse> getTransactions(@Valid @RequestBody WalletRequestModel requestModel)
			throws BankWalletException {
		List<Transaction> transactions = walletService.getTransactions(requestModel.getAccountNumber(),
				requestModel.getPassword());
		HashMap<String, Object> data = new HashMap<String, Object>();
		data.put("account_number", requestModel.getAccountNumber());
		data.put("transactions", transactions);
		SampleResponse sampleRespose = new SampleResponse(true, data);
		ResponseEntity<SampleResponse> response = new ResponseEntity<SampleResponse>(sampleRespose,
				HttpStatus.ACCEPTED);
		return response;
	}

	/*
	 * Deposits the amount in the account
	 * 
	 * @Return New Balance in ResponseEntity of Double
	 * 
	 * @Param Account number as String and password as String and amount as Double
	 * from request body
	 */
	@PostMapping(value = "/fund-transfer")
	public ResponseEntity<SampleResponse> fundTransfer(@Valid @RequestBody WalletRequestModel requestModel)
			throws BankWalletException {
		Double balance = walletService.fundTransfer(requestModel.getAccountNumber(), requestModel.getReceiver(),
				requestModel.getAmount(), requestModel.getPassword());
		HashMap<String, Object> data = new HashMap<String, Object>();
		data.put("account_number", requestModel.getAccountNumber());
		data.put("balance", balance);
		SampleResponse sampleRespose = new SampleResponse(true, data);
		ResponseEntity<SampleResponse> response = new ResponseEntity<SampleResponse>(sampleRespose,
				HttpStatus.ACCEPTED);
		return response;
	}

	/*
	 * Deposits the amount in the account
	 * 
	 * @Return New Balance in ResponseEntity of Double
	 * 
	 * @Param Account number as String and password as String and amount as Double
	 * from request body
	 */
	@PostMapping(value = "/deposit")
	public ResponseEntity<SampleResponse> deposit(@Valid @RequestBody WalletRequestModel requestModel)
			throws BankWalletException {
		Double balance = walletService.depositAmount(requestModel.getAccountNumber(), requestModel.getAmount(),
				requestModel.getPassword());
		HashMap<String, Object> data = new HashMap<String, Object>();
		data.put("account_number", requestModel.getAccountNumber());
		data.put("balance", balance);
		SampleResponse sampleRespose = new SampleResponse(true, data);
		ResponseEntity<SampleResponse> response = new ResponseEntity<SampleResponse>(sampleRespose,
				HttpStatus.ACCEPTED);
		return response;
	}

	/*
	 * withdraw the amount from the account
	 * 
	 * @Return Remaining Balance in ResponseEntity of Double
	 * 
	 * @Param Account number as String and password as String and amount as Double
	 * from request body
	 */
	@PostMapping(value = "/withdraw")
	public ResponseEntity<SampleResponse> withdraw(@Valid @RequestBody WalletRequestModel requestModel)
			throws BankWalletException {
		Double balance = walletService.withdrawAmount(requestModel.getAccountNumber(), requestModel.getAmount(),
				requestModel.getPassword());
		HashMap<String, Object> data = new HashMap<String, Object>();
		data.put("account_number", requestModel.getAccountNumber());
		data.put("balance", balance);
		SampleResponse sampleRespose = new SampleResponse(true, data);
		ResponseEntity<SampleResponse> response = new ResponseEntity<SampleResponse>(sampleRespose,
				HttpStatus.ACCEPTED);
		return response;
	}

}