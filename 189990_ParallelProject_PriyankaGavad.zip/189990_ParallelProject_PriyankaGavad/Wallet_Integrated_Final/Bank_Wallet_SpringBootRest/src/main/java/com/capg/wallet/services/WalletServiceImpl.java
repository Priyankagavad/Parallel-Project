package com.capg.wallet.services;

import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.wallet.beans.Account;
import com.capg.wallet.beans.Transaction;
import com.capg.wallet.dao.AccountDAO;
import com.capg.wallet.dao.TransactionDAO;
import com.capg.wallet.utils.BankWalletException;
import com.capg.wallet.utils.Utils;

/*
 * Implements abstract methods from WalletService Interface.
 */
@Service("walletService")
public class WalletServiceImpl implements WalletService {
	private AccountDAO accountDAO;
	private TransactionDAO transactionDAO;

	@Autowired
	public void setAccountDAO(AccountDAO accountDAO) {
		this.accountDAO = accountDAO;
	}

	@Autowired
	public void setTransactionDAO(TransactionDAO transactionDAO) {
		this.transactionDAO = transactionDAO;
	}

	/*
	 * Returns Account object by taking account number.
	 */
	private Account getAccount(String accountNum) throws BankWalletException {
		Optional<Account> result = accountDAO.findById(accountNum);
		Account account;
		try {
			account = result.get();
		} catch (NoSuchElementException e) {
			throw new BankWalletException("No account found for account number " + accountNum + ".");
		}
		return account;
	}

	/*
	 * Verifies if the account number and password are correct.
	 */
	private Account verifyAccount(String accountNum, String password) throws BankWalletException {
		Account account = getAccount(accountNum);
		if (!account.getPassword().equals(password)) {
			throw new BankWalletException("You have entered an incorrect passoword.");
		}
		return account;

	}

	/*
	 * prints current balance in the account
	 */
	@Override
	public double getBalance(String accountNum, String password) throws BankWalletException {
		Account account = verifyAccount(accountNum, password);
		return account.getBalance();
	}

	/*
	 * Prints all the transactions for a particular account
	 */
	@Override
	public List<Transaction> getTransactions(String accountNum, String password) throws BankWalletException {
		Account account = verifyAccount(accountNum, password);
		return transactionDAO.findTransactionByAccountFrom(account);
	}

	/*
	 * Creates a new account.
	 * 
	 * @param String name,String mobile,String dob,String password
	 * 
	 * @return Account Number in String Data type
	 */
	@Override
	public String createAccount(String name, String mobile, String dob, String password) throws BankWalletException {
		String accountNumber = Utils.randomString(3) + mobile;
		Account account = new Account();
		account.setName(name);
		account.setBalance(0);
		account.setDob(dob);
		account.setMobile(mobile);
		account.setAccountNumber(accountNumber);
		account.setPassword(password);
		Account resAccount = accountDAO.save(account);
		System.out.println("service" + resAccount);
		if (resAccount == null) {
			throw new BankWalletException("Could not create account.");
		}
		return accountDAO.save(account).getAccountNumber();
	}

	/*
	 * Creates a transaction object with the given details and passes it to
	 * createTransaction() method of WalletDao Interface.
	 */
	private String createTransaction(String accountFrom, double amount, String remark, String accountTo)
			throws BankWalletException {
		Transaction transaction = new Transaction();
		String uniqueKey = UUID.randomUUID().toString();
		String tranId = uniqueKey.split("-")[0];
		Account account = getAccount(accountFrom);
		transaction.setAccountFrom(account);
		transaction.setAmount(amount);
		transaction.setTime(new Date());
		transaction.setRemark(remark);
		transaction.setId(tranId);
		transaction.setAccountTo(accountTo);
		Transaction resTransaction = transactionDAO.save(transaction);
		if (resTransaction == null) {
			throw new BankWalletException(remark + " failed.");
		}
		accountDAO.save(account);
		return resTransaction.getId();
	}

	/*
	 * Deposits the amount into the account.
	 */
	@Override
	public double depositAmount(String accountNum, double amount, String password) throws BankWalletException {
		if (amount <= 0) {
			throw new BankWalletException("Please enter a valid amount.");
		}
		Account account = verifyAccount(accountNum, password);
		double newBalance = account.getBalance() + amount;
		account.setBalance(newBalance);
		accountDAO.save(account);
		createTransaction(accountNum, amount, "deposit", "NA");
		return newBalance;
	}

	/*
	 * Withdraws the amount from the account.
	 */
	@Override
	public double withdrawAmount(String accountNum, double amount, String password) throws BankWalletException {
		if (amount <= 0) {
			throw new BankWalletException("Please enter a valid amount.");
		}
		Account account = verifyAccount(accountNum, password);
		if (amount > account.getBalance()) {
			throw new BankWalletException("You have Insufficient funds in your account.");
		}
		double newBalance = account.getBalance() - amount;
		account.setBalance(newBalance);
		accountDAO.save(account);
		createTransaction(accountNum, amount, "withdraw", "NA");
		return newBalance;
	}

	/*
	 * Transfers the amount from one account to another.
	 */
	@Override
	public double fundTransfer(String senderAccNum, String recAccNum, double amount, String password)
			throws BankWalletException {
		if (amount <= 0) {
			throw new BankWalletException("Please enter a valid amount.");
		}
		Account account = verifyAccount(senderAccNum, password);
		if (amount > account.getBalance()) {
			throw new BankWalletException("You have Insufficient funds in your account.");
		}
		if (senderAccNum.equals(recAccNum)) {
			throw new BankWalletException("You cannot transfer funds to your own account.");
		}
		Account recAccount = getAccount(recAccNum);
		double senderBalance = account.getBalance() - amount;
		double recBalance = recAccount.getBalance() + amount;
		account.setBalance(senderBalance);
		recAccount.setBalance(recBalance);
		accountDAO.save(account);
		accountDAO.save(recAccount);
		createTransaction(senderAccNum, amount, "fund transfer", recAccNum);
		return senderBalance;
	}

}
