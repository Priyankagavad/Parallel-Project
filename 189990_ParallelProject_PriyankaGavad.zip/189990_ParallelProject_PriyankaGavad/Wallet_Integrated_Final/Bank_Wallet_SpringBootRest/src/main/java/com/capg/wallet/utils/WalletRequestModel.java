package com.capg.wallet.utils;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

public class WalletRequestModel {
	@NotNull(message = "account number should not be null")
	@NotBlank(message = "account number should not be blank")
	@JsonProperty("account_number")
	private String accountNumber;
	@NotNull(message = "password should not be null")
	@NotBlank(message = "password should not be blank")
	private String password;
	private double amount;
	private String receiver ="NA";

	public String getReceiver() {
		return receiver;
	}

	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}