export class SampleResponse {
    time: string;
    success: boolean;
    result: Array<any>;
    errors: Array<any>;
    constructor(time, success, result, errors) {
        this.time = time;
        this.success = success;
        this.result = result;
        this.errors = errors;
    }
}